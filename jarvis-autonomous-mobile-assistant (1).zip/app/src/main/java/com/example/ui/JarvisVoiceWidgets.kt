package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.ArcCyanGlow
import com.example.ui.theme.HoloDarkBg
import com.example.ui.theme.HoloSurface
import com.example.ui.theme.HoloSurfaceElevated
import com.example.ui.theme.HoloTextPrimary
import com.example.ui.theme.HoloTextSecondary
import com.example.ui.theme.StarkGold

/**
 * Voice Enrollment & Biometric Calibration Card ("Amar Voice" / My Voice)
 * Allows user to calibrate & save their vocal signature so JARVIS only obeys their voice.
 */
@Composable
fun VoiceBiometricEnrollmentCard(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    AmarVoiceLockCard(viewModel = viewModel, modifier = modifier)
}

/**
 * Live Talk Floating Round Action Pill ("Live kotha bolar option side gol round kore")
 */
@Composable
fun LiveTalkRoundFloatingBar(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val isLiveOrbActive = viewModel.isLiveOrbActive
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Surface(
        onClick = { viewModel.toggleLiveOrb() },
        color = HoloSurfaceElevated.copy(alpha = 0.95f),
        shape = RoundedCornerShape(32.dp),
        tonalElevation = 8.dp,
        modifier = modifier
            .clip(RoundedCornerShape(32.dp))
            .border(
                width = 1.5.dp,
                color = if (isLiveOrbActive) ArcCyanGlow else ArcCyan.copy(alpha = glowAlpha),
                shape = RoundedCornerShape(32.dp)
            )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            // Pulsing round dot / icon
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (isLiveOrbActive) Color.Red else ArcCyan.copy(alpha = 0.25f))
                    .border(1.dp, if (isLiveOrbActive) Color.White else ArcCyan, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Mic,
                    contentDescription = null,
                    tint = if (isLiveOrbActive) Color.White else ArcCyanGlow,
                    modifier = Modifier.size(14.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "LIVE TALK",
                    color = ArcCyanGlow,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isLiveOrbActive) "TAP TO CLOSE" else "LIVE KOTHA BOLUN",
                    color = HoloTextSecondary,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                Icons.Default.GraphicEq,
                contentDescription = null,
                tint = if (isLiveOrbActive) ArcCyanGlow else HoloTextSecondary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

/**
 * Full-screen / Modal Rounded Live Talk Orb Dialog
 * Displays a glowing round orb with real-time waveform pulses for natural duplex speaking.
 */
@Composable
fun LiveTalkRoundOrbDialog(
    viewModel: JarvisViewModel,
    onDismissRequest: () -> Unit
) {
    val isListening = viewModel.isListening
    val isDuplex = viewModel.isDuplexEnabled
    val lastLog = viewModel.coreLog

    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.92f))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .clip(RoundedCornerShape(32.dp))
                    .background(HoloSurface.copy(alpha = 0.96f))
                    .border(2.dp, ArcCyan.copy(alpha = 0.6f), RoundedCornerShape(32.dp))
                    .padding(24.dp)
            ) {
                // Header with rounded pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ArcCyan.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArcCyan),
                    modifier = Modifier.clip(RoundedCornerShape(20.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color.Red)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LIVE TALK // 2-WAY DUPLEX",
                            color = ArcCyanGlow,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Interactive Glowing Round Orb
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .clip(CircleShape)
                        .clickable {
                            viewModel.toggleListeningState()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = (size.minDimension / 2f) * pulseScale

                        // Outer glowing rings
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(ArcCyan.copy(alpha = 0.4f), Color.Transparent),
                                center = center,
                                radius = radius
                            ),
                            radius = radius
                        )

                        // Rotating segmented reactor arc
                        rotate(rotation, center) {
                            drawCircle(
                                color = ArcCyanGlow,
                                radius = radius * 0.82f,
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }

                        rotate(-rotation * 1.5f, center) {
                            drawCircle(
                                color = StarkGold,
                                radius = radius * 0.65f,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }

                        // Core reactor
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(Color.White, ArcCyan, ArcCyan.copy(alpha = 0.5f)),
                                center = center,
                                radius = radius * 0.45f
                            ),
                            radius = radius * 0.45f
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = if (isListening) "LISTENING" else "SPEAK",
                            color = Color.Black,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Live kotha bolun, JARVIS shunchhe...",
                    color = ArcCyanGlow,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (viewModel.voiceProfileState != null) "🔒 Protected: Obeying only your voice" else "🔓 Open Mic: Any speaker accepted",
                    color = if (viewModel.voiceProfileState != null) ArcCyan else StarkGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Live Feedback / Transcript
                Surface(
                    color = HoloDarkBg,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .border(1.dp, ArcCyan.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = lastLog.takeLast(160),
                            color = HoloTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 3
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Bottom Round Action Controls
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Barge-in / Duplex Button (Rounded)
                    OutlinedButton(
                        onClick = { viewModel.toggleDuplexMode() },
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isDuplex) ArcCyanGlow else Color.LightGray
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isDuplex) ArcCyan else Color.DarkGray
                        ),
                        modifier = Modifier.height(44.dp)
                    ) {
                        Icon(
                            if (isDuplex) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (isDuplex) "Duplex ON" else "Duplex OFF",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }

                    // Close Button (Rounded)
                    Button(
                        onClick = onDismissRequest,
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Red.copy(alpha = 0.85f),
                            contentColor = Color.White
                        ),
                        modifier = Modifier.height(44.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Close Live Talk", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
