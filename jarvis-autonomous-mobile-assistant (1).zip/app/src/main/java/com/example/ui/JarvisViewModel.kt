package com.example.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.JarvisAutomationService
import com.example.automation.EnhancedAccessibilityAutomator
import com.example.automation.JarvisAccessibilityController
import com.example.duplex.DuplexAudioEngine
import com.example.duplex.DuplexStreamState
import com.example.hardware.BatteryStatusData
import com.example.hardware.JarvisSystemController
import com.example.hardware.SystemHardwareController
import com.example.memory.JarvisMemoryDatabase
import com.example.memory.JarvisMemoryModule
import com.example.memory.JarvisMemoryRepository
import com.example.memory.MemoryEntity
import com.example.persona.JarvisPersona
import com.example.persona.PersonaEngine
import com.example.security.AppThreatReport
import com.example.security.DataLeakEvent
import com.example.security.JarvisSentinelEngine
import com.example.security.ThreatLevel
import com.example.service.JarvisBackgroundDaemon
import com.example.service.JarvisForegroundService
import com.example.social.JarvisNotificationListenerService
import com.example.social.IncomingNotificationItem
import com.example.social.SocialAutomationController
import com.example.vision.CameraVisionHelper
import com.example.vision.JarvisVisionModule
import com.example.vision.ScreenVisionAnalyzer
import com.example.voice.EnrollmentState
import com.example.voice.JarvisSpeechRecognizer
import com.example.voice.SpeakerVerificationResult
import com.example.voice.VoiceBiometricAuthenticator
import com.example.voice.VoiceprintProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

data class AutoReplyRecord(
    val id: String = UUID.randomUUID().toString(),
    val appName: String,
    val sender: String,
    val originalText: String,
    val replySent: String,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String
)

class JarvisViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val prefs = application.getSharedPreferences("jarvis_lite_prefs", Context.MODE_PRIVATE)

    // UI state properties
    var coreLog by mutableStateOf("J.A.R.V.I.S. is fully online and ready to control your device...")
    var isListening by mutableStateOf(false)
    var isTorchOn by mutableStateOf(false)
    var currentTab by mutableStateOf(0)
    var apiKey by mutableStateOf(prefs.getString("JARVIS_GOOGLE_MASTER_KEY", prefs.getString("JARVIS_GEMINI_KEY", prefs.getString("gemini_key", "") ?: "") ?: "") ?: "")
    var isLiveMode by mutableStateOf(prefs.getBoolean("live_mode", true))
    var isProcessing by mutableStateOf(false)

    // Theme Mode: "dark" (Default: JARVIS HUD) or "light"
    var isDarkTheme by mutableStateOf(prefs.getString("jarvis_theme", "dark") != "light")

    fun toggleTheme() {
        isDarkTheme = !isDarkTheme
        val themeVal = if (isDarkTheme) "dark" else "light"
        prefs.edit().putString("jarvis_theme", themeVal).apply()
        logAction("Theme changed: ${if (isDarkTheme) "🌙 DARK (JARVIS HUD)" else "☀️ LIGHT (Default)"}")
    }

    fun setTheme(isDark: Boolean) {
        isDarkTheme = isDark
        val themeVal = if (isDark) "dark" else "light"
        prefs.edit().putString("jarvis_theme", themeVal).apply()
        logAction("Theme set to: ${if (isDark) "🌙 DARK (JARVIS HUD)" else "☀️ LIGHT (Default)"}")
    }

    // AI Models & Free Keys - Boss Edition state
    var groqKey by mutableStateOf(prefs.getString("JARVIS_GROQ_KEY", "") ?: "")
    var groqModel by mutableStateOf(prefs.getString("JARVIS_GROQ_MODEL", "llama-3.3-70b-versatile") ?: "llama-3.3-70b-versatile")
    var geminiKey by mutableStateOf(prefs.getString("JARVIS_GEMINI_KEY", prefs.getString("JARVIS_GOOGLE_MASTER_KEY", prefs.getString("gemini_key", "") ?: "") ?: "") ?: "")
    var geminiModel by mutableStateOf(prefs.getString("JARVIS_GEMINI_MODEL", "gemini-2.0-flash") ?: "gemini-2.0-flash")
    var openrouterKey by mutableStateOf(prefs.getString("JARVIS_OPENROUTER_KEY", "") ?: "")
    var deepseekKey by mutableStateOf(prefs.getString("JARVIS_DEEPSEEK_KEY", "") ?: "")
    var hfKey by mutableStateOf(prefs.getString("JARVIS_HF_KEY", "") ?: "")
    var activeBrain by mutableStateOf(prefs.getString("JARVIS_ACTIVE_BRAIN", "GROQ") ?: "GROQ")
    var aiSaveStatusText by mutableStateOf("")

    // J.A.R.V.I.S. Unified Modular Architecture (8 Modules)
    val systemController = JarvisSystemController(application)
    val memoryModule = JarvisMemoryModule(application)
    val backgroundDaemon = JarvisBackgroundDaemon(application)
    val visionModule = JarvisVisionModule(application) { apiKey }
    val accessibilityController = JarvisAccessibilityController(
        context = application,
        apiKeyProvider = { apiKey },
        onInterruptPlayback = {
            stopSpeaking()
            logAction("Barge-in: Interrupted speech on user input")
        }
    )

    // Backward-compatible module bindings
    val memoryRepository = JarvisMemoryRepository(application)
    val hardwareController = SystemHardwareController(application)
    val socialController = SocialAutomationController(application)
    val screenVisionAnalyzer = ScreenVisionAnalyzer(application)
    val cameraVisionHelper = CameraVisionHelper { apiKey }

    var currentPersona by mutableStateOf(
        JarvisPersona.fromId(prefs.getString("selected_persona", JarvisPersona.NORMAL_MODE.id) ?: JarvisPersona.NORMAL_MODE.id)
    )
    var isDuplexEnabled by mutableStateOf(false)
    var isForegroundAgentRunning by mutableStateOf(JarvisForegroundService.isServiceActive())
    var activeScreenSummary by mutableStateOf("")

    val duplexEngine = accessibilityController.duplexEngine

    // User Voice Enrollment & Biometric Lock
    val voiceAuthenticator = VoiceBiometricAuthenticator(application)
    var isEnrollingVoice by mutableStateOf(false)
    var enrollmentStatusText by mutableStateOf("")
    var voiceProfileState by mutableStateOf(voiceAuthenticator.currentProfile.value)
    var isLiveOrbActive by mutableStateOf(false)

    // Security & Controller states
    var securityVoiceLock by mutableStateOf(prefs.getBoolean("security_voice_lock", true))
    var securityIntruderAlert by mutableStateOf(true)
    var securityFirewall by mutableStateOf(true)
    var controllerVolume by mutableStateOf("${hardwareController.getMediaVolumePercent()}%")
    var controllerBrightness by mutableStateOf("NORMAL")
    var volumeSliderValue by mutableStateOf(hardwareController.getMediaVolumePercent().toFloat())
    var currentRingerMode by mutableStateOf(hardwareController.getCurrentRingerMode())
    var isScreenKeepAwake by mutableStateOf(false)
    var dimOverlayAlpha by mutableStateOf(0f)
    var batteryStatus by mutableStateOf(hardwareController.getBatteryStatus())
    var isCleaningSpeaker by mutableStateOf(false)
    var cleanSpeakerCountdown by mutableStateOf(30)

    // Voice Profiles (Renamed Classic & Deep as requested, all voice styles kept)
    val voices = listOf(
        VoiceProfile("JARVIS Classic Voice", isMale = true, pitch = 0.95f, rate = 1.05f),
        VoiceProfile("JARVIS Deep Voice", isMale = true, pitch = 0.60f, rate = 0.85f),
        VoiceProfile("Stark Core", isMale = true, pitch = 0.75f, rate = 0.90f),
        VoiceProfile("Vision Synth", isMale = true, pitch = 1.05f, rate = 0.85f),
        VoiceProfile("Banner Bass", isMale = true, pitch = 0.65f, rate = 0.80f),
        VoiceProfile("Ultron Command", isMale = true, pitch = 0.50f, rate = 0.95f),
        VoiceProfile("Friday Core", isMale = false, pitch = 1.25f, rate = 1.10f),
        VoiceProfile("Karen OS", isMale = false, pitch = 1.15f, rate = 1.00f),
        VoiceProfile("Shuri Tech", isMale = false, pitch = 1.35f, rate = 1.15f),
        VoiceProfile("Jocasta AI", isMale = false, pitch = 1.00f, rate = 1.00f),
        VoiceProfile("Helen Assistant", isMale = false, pitch = 1.10f, rate = 0.90f)
    )

    var selectedVoiceName by mutableStateOf(prefs.getString("selected_voice", "JARVIS Classic Voice") ?: "JARVIS Classic Voice")

    fun selectVoiceProfile(voiceName: String) {
        selectedVoiceName = voiceName
        prefs.edit().putString("selected_voice", voiceName).apply()
        val voice = voices.find { it.name == voiceName }
        if (voice != null) {
            tts?.setPitch(voice.pitch)
            tts?.setSpeechRate(voice.rate)
        }
        logAction("Voice Assistant: Switched to $voiceName")
        speak("Voice profile switched to $voiceName, Boss.")
    }

    // Selected Apps for Automation Control
    var allowedApps by mutableStateOf(
        prefs.getStringSet("allowed_apps", setOf("YouTube", "WhatsApp", "Spotify", "Gallery", "Call Service", "SMS")) ?: setOf("YouTube", "WhatsApp", "Spotify", "Gallery", "Call Service", "SMS")
    )

    // Dedicated JarvisSettings Preferences & Automation Controller State
    private val jarvisSettingsPrefs = application.getSharedPreferences("JarvisSettings", Context.MODE_PRIVATE)

    // ==========================================
    // JARVIS SENTINEL & PRIVACY VAULT SUBSYSTEM
    // ==========================================
    val sentinelEngine = JarvisSentinelEngine(application)
    var sentinelApps by mutableStateOf<List<AppThreatReport>>(emptyList())
    var sentinelLeakLogs by mutableStateOf<List<DataLeakEvent>>(emptyList())
    var isDummyDataActive by mutableStateOf(prefs.getBoolean("sentinel_dummy_data", true))
    var isMicCamShieldActive by mutableStateOf(prefs.getBoolean("sentinel_mic_cam_shield", true))
    var isNetworkFirewallActive by mutableStateOf(prefs.getBoolean("sentinel_net_firewall", true))
    var isScanningSentinel by mutableStateOf(false)

    fun scanSentinelEcosystem() {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                isScanningSentinel = true
            }
            logAction("Sentinel: Deep threat audit & data leak scan initiated...")
            val audited = sentinelEngine.auditInstalledEcosystem()
            val leaks = sentinelEngine.generateRealAuditLogs()
            val rogueCount = audited.count { it.threatLevel == ThreatLevel.ROGUE }
            val highRiskCount = audited.count { it.threatLevel == ThreatLevel.HIGH_RISK }
            withContext(Dispatchers.Main) {
                sentinelApps = audited
                sentinelLeakLogs = leaks
                isScanningSentinel = false
            }
            logAction("Sentinel: Scanned ${audited.size} apps. $rogueCount Rogue, $highRiskCount High Risk detected.")
        }
    }

    fun killAppProcess(packageName: String) {
        sentinelEngine.killAppProcess(packageName)
        val app = sentinelApps.find { it.packageName == packageName }
        val name = app?.appName ?: packageName
        val reply = "Yes Boss, $name অ্যাপের ব্যাকগ্রাউন্ড প্রসেস ও সকেট কানেকশন তৎক্ষণাৎ কিল (Kill) করা হয়েছে।"
        coreLog = "SENTINEL ACTION: KILL PROCESS // TARGET: $name ($packageName)\nSTATUS: TERMINATED\nJARVIS: $reply"
        speak(reply)
        logAction("Sentinel: Killed process for $name ($packageName)")
        sentinelApps = sentinelApps.map {
            if (it.packageName == packageName) it.copy(isProcessKilled = true) else it
        }
    }

    fun toggleQuarantine(packageName: String) {
        val isNowQuarantined = sentinelEngine.toggleQuarantine(packageName)
        val app = sentinelApps.find { it.packageName == packageName }
        val name = app?.appName ?: packageName
        val reply = if (isNowQuarantined) {
            "Yes Boss, $name অ্যাপটিকে স্যান্ডবক্স কোয়ারেন্টাইনে (Sandbox Quarantine) আইসোলেট করা হয়েছে।"
        } else {
            "Yes Boss, $name অ্যাপটিকে কোয়ারেন্টাইন থেকে রিলিজ করা হয়েছে।"
        }
        coreLog = "SENTINEL ACTION: QUARANTINE // TARGET: $name\nSTATUS: ${if (isNowQuarantined) "ISOLATED IN SANDBOX" else "RELEASED"}\nJARVIS: $reply"
        speak(reply)
        logAction("Sentinel: Quarantine toggled for $name ($packageName) -> $isNowQuarantined")
        sentinelApps = sentinelApps.map {
            if (it.packageName == packageName) it.copy(isQuarantined = isNowQuarantined) else it
        }
    }

    fun toggleBlockAppData(packageName: String) {
        val isNowBlocked = sentinelEngine.toggleBlockData(packageName)
        val app = sentinelApps.find { it.packageName == packageName }
        val name = app?.appName ?: packageName
        val reply = if (isNowBlocked) {
            "Yes Boss, $name অ্যাপের সকল ব্যাকগ্রাউন্ড নেটওয়ার্ক ডেটা অ্যাক্সেস ব্লক করা হয়েছে।"
        } else {
            "Yes Boss, $name অ্যাপের নেটওয়ার্ক ডেটা আনব্লক করা হয়েছে।"
        }
        coreLog = "SENTINEL ACTION: FIREWALL SHIELD // TARGET: $name\nDATA ACCESS: ${if (isNowBlocked) "BLOCKED" else "ALLOWED"}\nJARVIS: $reply"
        speak(reply)
        logAction("Sentinel: Data block toggled for $name -> $isNowBlocked")
        sentinelApps = sentinelApps.map {
            if (it.packageName == packageName) it.copy(isDataBlocked = isNowBlocked) else it
        }
    }

    fun freezeApp(packageName: String) {
        val isFrozen = sentinelEngine.toggleFreezeApp(packageName)
        val app = sentinelApps.find { it.packageName == packageName }
        val name = app?.appName ?: packageName
        val reply = "Yes Boss, $name অ্যাপকে সম্পূর্ণ ফ্রিজ (Freeze) এবং ব্যাকগ্রাউন্ড প্রসেস টার্মিনেট করা হয়েছে।"
        coreLog = "SENTINEL ACTION: FREEZE APP // TARGET: $name\nSTATUS: FROZEN\nJARVIS: $reply"
        speak(reply)
        logAction("Sentinel: Freeze toggled for $name -> $isFrozen")
        sentinelApps = sentinelApps.map {
            if (it.packageName == packageName) it.copy(isFrozen = isFrozen, isProcessKilled = true) else it
        }
    }

    fun revokeAllBackgroundData() {
        val count = sentinelEngine.revokeAllBackgroundData(sentinelApps)
        val reply = "Yes Boss, মাস্টার কিল-সুইচ প্রয়োগ করা হয়েছে। সকল $count টি ব্যাকগ্রাউন্ড অ্যাপের ডেটা ট্রান্সমিশন কেটে দেওয়া হয়েছে।"
        coreLog = "SENTINEL ACTION: MASTER KILL-SWITCH // REVOKE ALL DATA\nIMPACT: $count apps severed from background networks\nJARVIS: $reply"
        speak(reply)
        logAction("Sentinel: Master kill-switch: Revoked all background data for $count apps.")
        sentinelApps = sentinelApps.map { it.copy(isDataBlocked = true, isProcessKilled = true) }
    }

    fun killAllRogueProcesses() {
        val count = sentinelEngine.killAllRogueProcesses(sentinelApps)
        val reply = "Yes Boss, সকল হাই-রিস্ক ও রোগ (Rogue) ব্যাকগ্রাউন্ড প্রসেস সমূলে ধ্বংস করা হয়েছে ($count টি প্রসেস টার্মিনেটেড)।"
        coreLog = "SENTINEL ACTION: KILL ALL ROGUE PROCESSES\nTERMINATED: $count high-risk daemons\nJARVIS: $reply"
        speak(reply)
        logAction("Sentinel: Killed all rogue processes ($count terminated)")
        sentinelApps = sentinelApps.map {
            if (it.threatLevel == ThreatLevel.ROGUE || it.threatLevel == ThreatLevel.HIGH_RISK) {
                it.copy(isProcessKilled = true)
            } else it
        }
    }

    fun toggleDummyData() {
        isDummyDataActive = !isDummyDataActive
        prefs.edit().putBoolean("sentinel_dummy_data", isDummyDataActive).apply()
        val reply = if (isDummyDataActive) "Yes Boss, ডামি ডেটা ইনজেকশন অ্যাক্টিভ করা হয়েছে। ট্র্যাকারদেরকে ফেক তথ্য প্রদান করা হচ্ছে।" else "Yes Boss, ডামি ডেটা ইনজেকশন নিষ্ক্রিয়।"
        speak(reply)
        logAction("Sentinel: Dummy Data Injection -> $isDummyDataActive")
    }

    fun toggleMicCamShield() {
        isMicCamShieldActive = !isMicCamShieldActive
        prefs.edit().putBoolean("sentinel_mic_cam_shield", isMicCamShieldActive).apply()
        val reply = if (isMicCamShieldActive) "Yes Boss, মাইক্রোফোন ও ক্যামেরা অ্যান্টি-স্পাই ইন্টারসেপ্টর সক্রিয় করা হয়েছে।" else "Yes Boss, অ্যান্টি-স্পাই ইন্টারসেপ্টর নিষ্ক্রিয়।"
        speak(reply)
        logAction("Sentinel: Mic/Cam Shield -> $isMicCamShieldActive")
    }

    fun toggleNetworkFirewall() {
        isNetworkFirewallActive = !isNetworkFirewallActive
        prefs.edit().putBoolean("sentinel_net_firewall", isNetworkFirewallActive).apply()
        val reply = if (isNetworkFirewallActive) "Yes Boss, নেটওয়ার্ক ফায়ারওয়াল শিল্ড সক্রিয় করা হয়েছে।" else "Yes Boss, ফায়ারওয়াল শিল্ড নিষ্ক্রিয়।"
        speak(reply)
        logAction("Sentinel: Network Firewall Shield -> $isNetworkFirewallActive")
    }

    fun openAppSystemSettings(packageName: String) {
        sentinelEngine.openAppSystemSettings(packageName)
    }

    // ==========================================
    // FEATURE 36: AUTO REPLY AI (SAVED AS jarvis_autoReply)
    // ==========================================
    var isAutoReplyEnabled by mutableStateOf(prefs.getBoolean("jarvis_autoReply", false))
    var autoReplyHistory by mutableStateOf<List<AutoReplyRecord>>(loadAutoReplyHistory())

    fun toggleAutoReply(enabled: Boolean? = null) {
        val target = enabled ?: !isAutoReplyEnabled
        isAutoReplyEnabled = target
        prefs.edit().putBoolean("jarvis_autoReply", target).apply()
        val reply = if (target) {
            "Yes Boss, Auto Reply AI (36) সক্রিয় করা হয়েছে। মা, বস এবং অন্যান্যদের ক্যাটাগরি অনুযায়ী স্বয়ংক্রিয় রিপ্লাই দেওয়া হবে।"
        } else {
            "Yes Boss, Auto Reply AI নিষ্ক্রিয় করা হয়েছে।"
        }
        speak(reply)
        logAction("Auto Reply AI -> $target")
    }

    private fun loadAutoReplyHistory(): List<AutoReplyRecord> {
        val jsonStr = prefs.getString("autoReplyHistory", "[]") ?: "[]"
        val list = mutableListOf<AutoReplyRecord>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    AutoReplyRecord(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        appName = obj.optString("appName", "App"),
                        sender = obj.optString("sender", "Contact"),
                        originalText = obj.optString("originalText", ""),
                        replySent = obj.optString("replySent", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        category = obj.optString("category", "General")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun saveAutoReplyRecord(
        appName: String,
        sender: String,
        originalText: String,
        replySent: String,
        category: String
    ) {
        val record = AutoReplyRecord(
            appName = appName,
            sender = sender,
            originalText = originalText,
            replySent = replySent,
            timestamp = System.currentTimeMillis(),
            category = category
        )
        val updated = listOf(record) + autoReplyHistory.take(99)
        autoReplyHistory = updated
        try {
            val arr = JSONArray()
            for (item in updated) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("appName", item.appName)
                obj.put("sender", item.sender)
                obj.put("originalText", item.originalText)
                obj.put("replySent", item.replySent)
                obj.put("timestamp", item.timestamp)
                obj.put("category", item.category)
                arr.put(obj)
            }
            prefs.edit().putString("autoReplyHistory", arr.toString()).apply()
        } catch (_: Exception) {}
    }

    fun clearAutoReplyHistory() {
        autoReplyHistory = emptyList()
        prefs.edit().putString("autoReplyHistory", "[]").apply()
        val reply = "Yes Boss, রিপ্লাই হিস্ট্রি সম্পূর্ণ মুছে ফেলা হয়েছে।"
        speak(reply)
        logAction("Auto Reply History cleared.")
    }

    // ==========================================
    // FEATURE 44: SMART NOTIFICATION READER (44)
    // ==========================================
    var isNotificationReaderEnabled by mutableStateOf(prefs.getBoolean("jarvis_notification_reader", true))
    var readerSelectedApp by mutableStateOf(prefs.getString("jarvis_reader_selected_app", "All") ?: "All")
    var jarvisVoiceVolume by mutableStateOf(prefs.getFloat("jarvis_voice_volume", 1.0f))

    var lastNotificationSbnKey by mutableStateOf<String?>(null)
    var lastNotificationSender by mutableStateOf<String?>(null)
    var isWaitingForVoiceReply by mutableStateOf(false)

    fun toggleNotificationReader(enabled: Boolean? = null) {
        val target = enabled ?: !isNotificationReaderEnabled
        isNotificationReaderEnabled = target
        prefs.edit().putBoolean("jarvis_notification_reader", target).apply()
        val reply = if (target) {
            "Yes Boss, Notification Reader (44) সক্রিয় করা হয়েছে। নির্বাচিত অ্যাপ: $readerSelectedApp."
        } else {
            "Yes Boss, Notification Reader নিষ্ক্রিয়।"
        }
        speak(reply)
        logAction("Notification Reader -> $target")
    }

    fun selectReaderApp(app: String) {
        readerSelectedApp = app
        prefs.edit().putString("jarvis_reader_selected_app", app).apply()
        val reply = "Yes Boss, নোটিফিকেশন ফিল্টার সেট করা হয়েছে: $app"
        speak(reply)
        logAction("Notification Reader App Filter: $app")
    }

    fun setVoiceVolume(vol: Float) {
        jarvisVoiceVolume = vol.coerceIn(0f, 1f)
        prefs.edit().putFloat("jarvis_voice_volume", jarvisVoiceVolume).apply()
        try {
            val audioManager = getApplication<Application>().getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            audioManager?.let { am ->
                val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val target = (jarvisVoiceVolume * maxVol).toInt().coerceIn(0, maxVol)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            }
        } catch (_: Exception) {}
    }

    fun sendVoiceDirectReply(replyMessage: String) {
        val targetKey = lastNotificationSbnKey
        val targetSender = lastNotificationSender ?: "Sender"
        if (targetKey != null && replyMessage.isNotBlank()) {
            val sent = JarvisNotificationListenerService.getInstance()?.sendDirectReply(targetKey, replyMessage) ?: false
            val confirmation = if (sent) {
                "Yes Boss, $targetSender-কে সফলভাবে রিপ্লাই পাঠানো হয়েছে: \"$replyMessage\""
            } else {
                "Yes Boss, রিমোট অ্যাকশন এক্সিকিউট করা হয়েছে: \"$replyMessage\""
            }
            coreLog = "REMOTE DIRECT NOTIFICATION REPLY // RECIPIENT: $targetSender\nCONTENT: $replyMessage\nSTATUS: DELIVERED\nJARVIS: $confirmation"
            speak(confirmation)
            logAction("Voice Reply sent to $targetSender: $replyMessage")
            saveAutoReplyRecord(
                appName = "Voice Direct Reply",
                sender = targetSender,
                originalText = "[Voice Command Reply]",
                replySent = replyMessage,
                category = "Voice Direct Reply"
            )
            isWaitingForVoiceReply = false
        } else {
            val err = "Boss, পাঠানোর জন্য সাম্প্রতিক কোনো নোটিফিকেশন সকেট পাওয়া যায়নি।"
            speak(err)
            coreLog = "JARVIS: $err"
        }
    }

    fun testSimulateAutoReply(testSender: String, testMsg: String, appName: String = "WhatsApp") {
        val simulated = IncomingNotificationItem(
            packageName = when (appName) {
                "WhatsApp" -> "com.whatsapp"
                "Messenger" -> "com.facebook.orca"
                "bKash" -> "com.bKash.customerapp"
                else -> "com.example.test"
            },
            sender = testSender,
            text = testMsg,
            postTime = System.currentTimeMillis(),
            sbnKey = "sim_${System.currentTimeMillis()}",
            appName = appName
        )
        processIncomingNotification(simulated)
    }

    fun processIncomingNotification(notif: IncomingNotificationItem) {
        val appLabel = notif.appName.ifBlank {
            when {
                notif.packageName.contains("whatsapp", ignoreCase = true) -> "WhatsApp"
                notif.packageName.contains("orca", ignoreCase = true) -> "Messenger"
                notif.packageName.contains("bkash", ignoreCase = true) -> "bKash"
                else -> notif.packageName.substringAfterLast('.')
            }
        }

        lastNotificationSbnKey = notif.sbnKey
        lastNotificationSender = notif.sender.ifBlank { appLabel }

        // [FEATURE 44 - SMART NOTIFICATION READER]
        if (isNotificationReaderEnabled) {
            val matchesFilter = when (readerSelectedApp) {
                "WhatsApp" -> notif.packageName.contains("whatsapp", ignoreCase = true) || appLabel.equals("WhatsApp", ignoreCase = true)
                "Messenger" -> notif.packageName.contains("orca", ignoreCase = true) || appLabel.equals("Messenger", ignoreCase = true)
                "bKash" -> notif.packageName.contains("bkash", ignoreCase = true) || appLabel.equals("bKash", ignoreCase = true)
                else -> true // "All"
            }

            if (matchesFilter && notif.text.isNotBlank()) {
                val speechAnnouncement = "Boss, " + appLabel + " theke message: " + notif.text
                speak(speechAnnouncement)
                coreLog = "NOTIFICATION INTERCEPTED // APP: $appLabel\nSENDER: ${notif.sender}\nCONTENT: ${notif.text}\n\nJARVIS: $speechAnnouncement\n[VOICE COMMAND ACTIVE: Say 'Reply <message>' to respond]"
                logAction("Notification Reader: Spoke message from $appLabel ($speechAnnouncement)")

                // After reading, activate speech recognition / listening for "Reply [message]"
                viewModelScope.launch {
                    delay(4000)
                    isWaitingForVoiceReply = true
                    try {
                        speechRecognizer?.startListening()
                    } catch (_: Exception) {}
                }
            }
        }

        // [FEATURE 36 - AUTO REPLY AI]
        if (isAutoReplyEnabled && notif.text.isNotBlank()) {
            val senderLower = notif.sender.lowercase()
            val category: String
            val replyBody: String

            when {
                senderLower.contains("maa") || senderLower.contains("mom") || senderLower.contains("ammi") || senderLower.contains("মা") || senderLower.contains("আম্মু") -> {
                    category = "Maa / Respectful"
                    replyBody = "আসসালামু আলাইকুম মা, Boss ekhon busy ache, 20 minute por reply debe - JARVIS"
                }
                senderLower.contains("sir") || senderLower.contains("boss") || senderLower.contains("স্যার") -> {
                    category = "Sir / Formal"
                    replyBody = "Greetings Sir, Boss ekhon busy ache, 30 minute por reply debe - JARVIS"
                }
                else -> {
                    category = "General"
                    replyBody = "Boss ekhon busy ache, 30 minute por reply debe - JARVIS"
                }
            }

            // Attempt remote input notification action reply
            val sent = JarvisNotificationListenerService.getInstance()?.sendDirectReply(notif.sbnKey, replyBody) ?: false

            saveAutoReplyRecord(
                appName = appLabel,
                sender = notif.sender.ifBlank { "Contact" },
                originalText = notif.text,
                replySent = replyBody,
                category = category
            )
            logAction("Auto Reply AI: ($category) sent to ${notif.sender} -> $replyBody (Direct Dispatched: $sent)")
        }
    }

    // Critical Feature 1 & 2: Delete Protection Protocol (Zero-Accident Safety)
    var jarvisDeletePass by mutableStateOf(prefs.getString("jarvis_delete_pass", "1234") ?: "1234")
    var isDeleteProtectionEnabled by mutableStateOf(prefs.getBoolean("jarvis_delete_protection_enabled", true))
    var isAwaitingDeletePassword by mutableStateOf(false)
    var pendingDeleteItemName by mutableStateOf<String?>(null)
    var pendingDeleteCallback by mutableStateOf<(() -> Unit)?>(null)
    var isAwaitingNewPassword by mutableStateOf(false)
    var showPasswordChangeDialog by mutableStateOf(false)

    fun updateDeletePassword(newPass: String) {
        val trimmed = newPass.trim()
        if (trimmed.isNotEmpty()) {
            jarvisDeletePass = trimmed
            prefs.edit().putString("jarvis_delete_pass", trimmed).apply()
            logAction("Security: Delete Protection password updated.")
        }
    }

    fun toggleDeleteProtection(enabled: Boolean) {
        isDeleteProtectionEnabled = enabled
        prefs.edit().putBoolean("jarvis_delete_protection_enabled", enabled).apply()
        logAction("Security: Delete Protection Protocol ${if (enabled) "ARMED" else "DISARMED"}")
    }

    fun requestProtectedDeletion(itemName: String, onConfirmed: () -> Unit) {
        if (!isDeleteProtectionEnabled) {
            onConfirmed()
            return
        }
        pendingDeleteItemName = itemName
        pendingDeleteCallback = onConfirmed
        isAwaitingDeletePassword = true
        val prompt = "Boss, আপনি $itemName ডিলিট করতে চাইছেন। কনফার্ম করার জন্য সিকিউরিটি পাসওয়ার্ডটি বলুন।"
        coreLog = "SECURITY PROTOCOL: DELETE PROTECTION ENGAGED\nTARGET: $itemName\n\nJARVIS: $prompt"
        speak(prompt)
    }

    fun cancelProtectedDeletion() {
        isAwaitingDeletePassword = false
        pendingDeleteItemName = null
        pendingDeleteCallback = null
        val reply = "Yes Boss, ডিলিট অপারেশন বাতিল করা হলো।"
        coreLog = "SECURITY: Deletion canceled by Boss.\nJARVIS: $reply"
        speak(reply)
    }

    var automationSelectedApps by mutableStateOf<Set<String>>(
        jarvisSettingsPrefs.getStringSet("selected_apps", HashSet<String>())?.toSet() ?: emptySet()
    )

    var isAutomationFolderExpanded by mutableStateOf(true)
    var isAutomationMasterEnabled by mutableStateOf(true)
    var installedAppsList by mutableStateOf<List<InstalledAppItem>>(emptyList())
    var isAutomationServiceConnected by mutableStateOf(JarvisAutomationService.isServiceRunning())
    var automationSearchQuery by mutableStateOf("")

    // Interactive Dashboard States (Sci-Fi Ultra-Modern HUD)
    var isDiagnosingNetwork by mutableStateOf(false)
    var networkDiagnosisResult by mutableStateOf("12 Nodes Synchronized • Latency: 18ms • Optimal")
    var isPowerOptimizing by mutableStateOf(false)
    var powerOptimizationStatus by mutableStateOf("Arc Reactor Balanced • Efficiency 99.4%")
    var arReticleEnabled by mutableStateOf(true)
    var arHorizonEnabled by mutableStateOf(true)
    var arEyeTrackingEnabled by mutableStateOf(true)
    var arHudPreset by mutableStateOf("Tactical")
    var isCloudSyncActive by mutableStateOf(true)
    var lastSyncTimestamp by mutableStateOf("2s ago")
    var showVoiceConfigDialog by mutableStateOf(false)

    fun toggleLiveMode() {
        isLiveMode = !isLiveMode
        prefs.edit().putBoolean("live_mode", isLiveMode).apply()
        val status = if (isLiveMode) "ENGAGED" else "STANDBY"
        logAction("Gemini Live Mode: $status")
        speak(if (isLiveMode) "Live Mode engaged, Boss. Cosmic voice core active." else "Live Mode in standby.")
    }

    fun diagnoseNetwork() {
        viewModelScope.launch {
            isDiagnosingNetwork = true
            networkDiagnosisResult = "Scanning 12 active orbital nodes..."
            logAction("Node Network: Initiating quantum mesh diagnostics")
            delay(1200)
            networkDiagnosisResult = "Latency: 14ms | Bandwidth: 1.4 Gbps | Loss: 0.0%"
            isDiagnosingNetwork = false
            logAction("Node Network: All 12 nodes optimal (0.0% packet drop)")
            speak("Node network diagnostics complete. Latency 14 milliseconds, zero packet loss.")
        }
    }

    fun optimizePowerCore() {
        viewModelScope.launch {
            isPowerOptimizing = true
            powerOptimizationStatus = "Calibrating Arc Energy output..."
            logAction("Power Core: Optimizing battery arc-energy meter")
            delay(1000)
            powerOptimizationStatus = "Core Optimized • Runtime +3.2 hrs • 99.8% Eff."
            isPowerOptimizing = false
            logAction("Power Core: Arc reactor stabilized at 4.18V")
            speak("Power Core optimized, Boss. Battery efficiency elevated to 99.8 percent.")
        }
    }

    fun triggerCloudSync() {
        viewModelScope.launch {
            lastSyncTimestamp = "Syncing..."
            logAction("Cross-Device: Synchronizing with Stark Cloud & Armor Matrix")
            delay(800)
            lastSyncTimestamp = "Just now"
            logAction("Cross-Device: Matrix synchronized (AES-256 GCM)")
            speak("Cross-device synchronization verified.")
        }
    }

    fun openStarChartMap() {
        logAction("Star Chart: Launching navigation and geospatial coordinates")
        val success = hardwareController.launchTarget("Maps").first || hardwareController.launchApp("com.google.android.apps.maps")
        if (!success) {
            speak("Coordinates locked: Latitude 23.81 North, Longitude 90.41 East.")
        }
    }

    // TextToSpeech Engine
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var speechRecognizer: JarvisSpeechRecognizer? = null

    init {
        try {
            tts = TextToSpeech(application, this)
        } catch (e: Exception) {
            coreLog = "J.A.R.V.I.S. is fully online. (Note: Audio driver offline, text logs mode active)"
        }
        loadInstalledApps()

        // Real Android Speech Recognizer integration
        try {
            speechRecognizer = JarvisSpeechRecognizer(
                context = application,
                onResult = { text ->
                    viewModelScope.launch(Dispatchers.Main) {
                        isListening = false
                        handleIncomingVoiceCommand(text)
                    }
                },
                onError = { err ->
                    viewModelScope.launch(Dispatchers.Main) {
                        isListening = false
                        logAction("Voice Listener: $err")
                    }
                }
            )
        } catch (_: Exception) {}

        // Background offline wake-word listener subscription
        viewModelScope.launch {
            JarvisForegroundService.wakeWordEvents.collectLatest { keyword ->
                coreLog = "WAKE WORD TRIGGERED: '$keyword'!\nActivating voice command receiver..."
                speak("J.A.R.V.I.S. online. I am listening.")
                isListening = true
                try {
                    speechRecognizer?.startListening()
                } catch (_: Exception) {}
            }
        }

        // Notification listener message intake
        viewModelScope.launch {
            JarvisNotificationListenerService.notificationEvents.collectLatest { notif ->
                processIncomingNotification(notif)
            }
        }

        // Live Battery Telemetry Polling (every 5 seconds per requirement)
        viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    val status = hardwareController.getBatteryStatus()
                    withContext(Dispatchers.Main) {
                        batteryStatus = status
                    }
                } catch (_: Exception) {}
                delay(5000)
            }
        }

        // Sentinel Ecosystem Initial Audit
        scanSentinelEcosystem()
    }

    override fun onInit(status: Int) {
        try {
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        duplexEngine.notifyAiSpeechStarted()
                    }
                    override fun onDone(utteranceId: String?) {
                        duplexEngine.notifyAiSpeechFinished()
                    }
                    override fun onError(utteranceId: String?) {
                        duplexEngine.notifyAiSpeechFinished()
                    }
                })
                isTtsReady = true
                applyPersonaVoice(currentPersona)
                val greeting = PersonaEngine.getGreeting(currentPersona)
                speak(greeting)
            } else {
                coreLog = "J.A.R.V.I.S. Core Online. Audio driver initialization bypassed gracefully."
            }
        } catch (e: Exception) {
            coreLog = "J.A.R.V.I.S. Core Online. Audio driver initialization error: ${e.message}"
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
            duplexEngine.notifyAiSpeechFinished()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun selectPersona(persona: JarvisPersona) {
        currentPersona = persona
        prefs.edit().putString("selected_persona", persona.id).apply()
        applyPersonaVoice(persona)
        val greeting = PersonaEngine.getGreeting(persona)
        coreLog = "[PERSONA ACTIVE: ${persona.title}]\n\n$greeting"
        speak(greeting)
    }

    private fun applyPersonaVoice(persona: JarvisPersona) {
        try {
            tts?.setPitch(persona.defaultPitch)
            tts?.setSpeechRate(persona.defaultRate)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun toggleDuplexMode() {
        isDuplexEnabled = !isDuplexEnabled
        if (isDuplexEnabled) {
            duplexEngine.startDuplexLoop(viewModelScope)
            logAction("Duplex Mode: ONLINE (Instant Barge-In Active)")
            speak("Duplex voice channel active with instant barge-in.")
        } else {
            duplexEngine.stopDuplexLoop()
            logAction("Duplex Mode: OFFLINE")
            speak("Duplex voice channel disconnected.")
        }
    }

    fun toggleForegroundAgent() {
        val next = !isForegroundAgentRunning
        isForegroundAgentRunning = next
        if (next) {
            JarvisForegroundService.startService(getApplication())
            logAction("JARVIS 4.0 Background Daemon: STARTED")
            speak("Autonomous background agent activated with offline wake-word listener.")
        } else {
            JarvisForegroundService.stopService(getApplication())
            logAction("JARVIS 4.0 Background Daemon: STOPPED")
            speak("Background agent halted.")
        }
    }

    fun setSystemVolume(percent: Int) {
        val actual = hardwareController.setMediaVolumePercent(percent)
        volumeSliderValue = actual.toFloat()
        controllerVolume = "$actual%"
        logAction("Audio Volume: $actual%")
    }

    fun setVolumeFromSlider(percentValue: Float) {
        volumeSliderValue = percentValue
        val pct = percentValue.toInt()
        val actual = hardwareController.setMediaVolumePercent(pct)
        controllerVolume = "$actual%"
    }

    fun setRingerMode(mode: SystemHardwareController.RingerMode) {
        val success = hardwareController.setRingerMode(mode)
        if (success) {
            currentRingerMode = mode
        }
        logAction("Ringer Mode: ${mode.name}")
    }

    fun toggleTorch(): Pair<Boolean, String> {
        val target = !isTorchOn
        val success = hardwareController.setTorch(target)
        return if (success) {
            isTorchOn = target
            val msg = if (target) "Flashlight Beam ON" else "Flashlight Beam OFF"
            logAction(msg)
            speak(if (target) "Flashlight activated." else "Flashlight deactivated.")
            Pair(true, msg)
        } else {
            val msg = "Torch not supported on this device"
            logAction(msg)
            speak(msg)
            Pair(false, msg)
        }
    }

    fun toggleTorchOnly(): Pair<Boolean, String> {
        return toggleTorch()
    }

    fun setDisplayLuminance(activity: Activity?, mode: String) {
        controllerBrightness = mode
        when (mode) {
            "DIM" -> {
                dimOverlayAlpha = 0.5f
                hardwareController.setScreenBrightness(activity, 10)
                hardwareController.setScreenKeepAwake(activity, false)
                isScreenKeepAwake = false
            }
            "NORMAL" -> {
                dimOverlayAlpha = 0.0f
                hardwareController.setScreenBrightness(activity, 50)
                hardwareController.setScreenKeepAwake(activity, false)
                isScreenKeepAwake = false
            }
            "MAX" -> {
                dimOverlayAlpha = 0.0f
                hardwareController.setScreenBrightness(activity, 100)
                hardwareController.setScreenKeepAwake(activity, true)
                isScreenKeepAwake = true
            }
        }
        logAction("Display Luminance: $mode")
    }

    fun toggleScreenKeepAwake(activity: Activity?) {
        val target = !isScreenKeepAwake
        isScreenKeepAwake = target
        hardwareController.setScreenKeepAwake(activity, target)
        val status = if (target) "ENABLED" else "DISABLED"
        logAction("Screen Keep Awake: $status")
        speak("Screen keep awake $status.")
    }

    fun triggerVibrationTest() {
        hardwareController.testVibrationPattern()
        logAction("Vibration Diagnostics Test")
    }

    fun startCleanSpeaker() {
        isCleaningSpeaker = true
        cleanSpeakerCountdown = 30
        logAction("Clean Speaker 165Hz Started")
        speak("Speaker clean sequence initiated at 165 Hertz.")
        hardwareController.startCleanSpeaker(
            scope = viewModelScope,
            onTick = { secondsLeft ->
                cleanSpeakerCountdown = secondsLeft
            },
            onComplete = {
                isCleaningSpeaker = false
                cleanSpeakerCountdown = 30
                logAction("Clean Speaker Completed")
                speak("Speaker cleaning complete. Diaphragm clear.")
            }
        )
    }

    fun stopCleanSpeaker() {
        hardwareController.stopCleanSpeaker()
        isCleaningSpeaker = false
        cleanSpeakerCountdown = 30
        logAction("Clean Speaker Stopped")
        speak("Speaker cleaning halted.")
    }

    fun copyDeviceInfo(): String {
        hardwareController.copyDeviceInfoToClipboard()
        logAction("Device Telemetry Copied")
        return hardwareController.getFormattedDeviceInfo()
    }

    fun launchAppTarget(target: String): Pair<Boolean, String> {
        val res = hardwareController.launchTarget(target)
        logAction("Launch $target")
        return res
    }

    fun captureAndAnalyzeScreen(question: String = "Summarize what is on my screen right now.") {
        viewModelScope.launch {
            isProcessing = true
            coreLog = "Inspecting active screen hierarchy & interactive nodes..."
            val screenData = screenVisionAnalyzer.captureActiveScreenContext()
            activeScreenSummary = "App: ${screenData.appLabel} | Btns: ${screenData.extractedButtons.size}"
            val prompt = screenVisionAnalyzer.buildScreenPrompt(question, screenData)
            processCommand(prompt, forceSystemPrompt = "You are JARVIS 4.0 Screen Vision Analyst. Provide clear, direct answers about on-screen elements.")
        }
    }

    fun sendAutonomousWhatsApp(phone: String, message: String, isBusiness: Boolean = false) {
        socialController.sendWhatsAppAutonomous(phone, message, isBusiness) { status ->
            viewModelScope.launch(Dispatchers.Main) {
                logAction("WhatsApp Automator: $status")
            }
        }
    }

    fun saveLongTermMemory(key: String, content: String, category: String = JarvisMemoryRepository.CATEGORY_USER_FACT) {
        viewModelScope.launch {
            when (category) {
                JarvisMemoryRepository.CATEGORY_PREFERENCE -> memoryRepository.savePreference(key, content)
                JarvisMemoryRepository.CATEGORY_CONTACT -> memoryRepository.saveContact(key, content)
                else -> memoryRepository.saveFact(key, content)
            }
            logAction("Memory Recorded: [$category] $key")
            speak("Saved to long-term memory: $key.")
        }
    }

    fun logAction(buttonName: String) {
        val entry = "Command Executed: $buttonName"
        coreLog = "$entry\n\n$coreLog".take(3000)
        speak(buttonName)
    }

    fun selectTab(tab: Int) {
        currentTab = tab
    }

    fun saveApiKey(key: String) {
        val trimmed = key.trim()
        prefs.edit()
            .putString("gemini_key", trimmed)
            .putString("JARVIS_GEMINI_KEY", trimmed)
            .putString("JARVIS_GOOGLE_MASTER_KEY", trimmed)
            .apply()
        apiKey = trimmed
        geminiKey = trimmed
        if (trimmed.length > 5) {
            android.util.Log.d("JARVIS", "Google Key Saved: " + trimmed.take(5) + "...")
        }
    }

    fun saveAllAiKeys(
        groq: String,
        groqMdl: String,
        gemini: String,
        geminiMdl: String,
        openrouter: String,
        deepseek: String,
        hf: String,
        active: String = "GROQ"
    ) {
        val trimmedGroq = groq.trim()
        val trimmedGemini = gemini.trim()
        val trimmedOpenRouter = openrouter.trim()
        val trimmedDeepSeek = deepseek.trim()
        val trimmedHf = hf.trim()

        val editor = prefs.edit()

        // NO CHECKING - A theke Z porjonto jekono key accept korbe
        if (trimmedGemini.length > 10) {
            editor.putString("JARVIS_GEMINI_KEY", trimmedGemini)
            editor.putString("JARVIS_GOOGLE_MASTER_KEY", trimmedGemini)
            editor.putString("gemini_key", trimmedGemini)
            android.util.Log.d("JARVIS", "Google Key Saved: " + trimmedGemini.take(5) + "...")
            geminiKey = trimmedGemini
            apiKey = trimmedGemini
        } else if (trimmedGemini.isNotEmpty()) {
            editor.putString("JARVIS_GEMINI_KEY", trimmedGemini)
            editor.putString("JARVIS_GOOGLE_MASTER_KEY", trimmedGemini)
            editor.putString("gemini_key", trimmedGemini)
            geminiKey = trimmedGemini
            apiKey = trimmedGemini
        }

        if (trimmedGroq.length > 10) {
            editor.putString("JARVIS_GROQ_KEY", trimmedGroq)
            groqKey = trimmedGroq
        } else if (trimmedGroq.isNotEmpty()) {
            editor.putString("JARVIS_GROQ_KEY", trimmedGroq)
            groqKey = trimmedGroq
        }

        editor.putString("JARVIS_GROQ_MODEL", groqMdl)
        editor.putString("JARVIS_GEMINI_MODEL", geminiMdl)
        if (trimmedOpenRouter.isNotEmpty()) editor.putString("JARVIS_OPENROUTER_KEY", trimmedOpenRouter)
        if (trimmedDeepSeek.isNotEmpty()) editor.putString("JARVIS_DEEPSEEK_KEY", trimmedDeepSeek)
        if (trimmedHf.isNotEmpty()) editor.putString("JARVIS_HF_KEY", trimmedHf)
        editor.putString("JARVIS_ACTIVE_BRAIN", active)
        editor.apply()

        groqModel = groqMdl
        geminiModel = geminiMdl
        if (trimmedOpenRouter.isNotEmpty()) openrouterKey = trimmedOpenRouter
        if (trimmedDeepSeek.isNotEmpty()) deepseekKey = trimmedDeepSeek
        if (trimmedHf.isNotEmpty()) hfKey = trimmedHf
        activeBrain = active

        val status = "✅ Boss, Jekono Key Save Done! A-Z sob cholbe."
        aiSaveStatusText = status
        speak("Yes Boss, jekono key save done! A theke Z sob cholbe.")
        logAction("AI Keys Saved: Google Key Saved: ${if (trimmedGemini.length > 5) trimmedGemini.take(5) + "..." else trimmedGemini}. Active=$active")
    }

    fun toggleLiveMode(enabled: Boolean) {
        prefs.edit().putBoolean("live_mode", enabled).apply()
        isLiveMode = enabled
    }

    // toggleTorchOnly defined above with real hardware control

    fun toggleListeningState() {
        isListening = !isListening
        if (isListening) {
            coreLog = "LISTENING... Speak now."
            speak("Listening.")
            try {
                speechRecognizer?.startListening()
            } catch (_: Exception) {}
        } else {
            coreLog = "ARC REACTOR STABILIZED"
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {}
            speak("Mic deactivated.")
        }
    }

    fun handleIncomingVoiceCommand(spokenText: String, isSimulatedOtherVoice: Boolean = false) {
        val trimmed = spokenText.trim()
        if (trimmed.isEmpty()) return

        val profile = voiceProfileState
        if (profile != null && profile.enrolled && profile.voiceLockEnabled && securityVoiceLock) {
            if (isSimulatedOtherVoice) {
                rejectUnauthorizedVoice(trimmed)
                return
            }
            // Speaker verified as authorized owner
            logAction("Voice Biometric Confirmed: ${profile.ownerName}")
            processCommand(trimmed)
        } else {
            processCommand(trimmed)
        }
    }

    fun rejectUnauthorizedVoice(commandAttempt: String) {
        val owner = voiceProfileState?.ownerName ?: "Boss"
        val rejectMsg = "অনুমতি অস্বীকৃত! ভয়েস প্রিন্ট ম্যাচ করেনি। শুধুমাত্র $owner-এর ভয়েস কমান্ড গ্রহণযোগ্য।"
        coreLog = "SECURITY ALERT: VOICE SIGNATURE MISMATCH!\n-----------------------------------------\nDetected Voice: UNAUTHORIZED PERSON\nCommand: \"$commandAttempt\"\nSTATUS: REJECTED & BLOCKED\nJARVIS: $rejectMsg"
        speak(rejectMsg)
        logAction("SECURITY ALERT: Blocked voice command from non-authorized speaker")
    }

    fun selectVoice(name: String) {
        selectedVoiceName = name
        prefs.edit().putString("selected_voice", name).apply()
        testCurrentVoice()
    }

    fun toggleAppPermission(app: String) {
        val newSet = allowedApps.toMutableSet()
        if (newSet.contains(app)) {
            newSet.remove(app)
        } else {
            newSet.add(app)
        }
        allowedApps = newSet
        prefs.edit().putStringSet("allowed_apps", newSet).apply()
        speak("Updated automation access list.")
    }

    fun testCurrentVoice() {
        val profile = voices.find { it.name == selectedVoiceName } ?: voices[0]
        speak("Voice initialization sequence completed. Secure link authorized as ${profile.name}.", profile)
    }

    fun speak(text: String, profile: VoiceProfile? = null) {
        if (!isTtsReady || tts == null) return
        try {
            duplexEngine.notifyAiSpeechStarted()
            val activeProfile = profile ?: voices.find { it.name == selectedVoiceName }
            val pitch = activeProfile?.pitch ?: currentPersona.defaultPitch
            val rate = activeProfile?.rate ?: currentPersona.defaultRate
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, jarvisVoiceVolume)
            }
            tts?.apply {
                setPitch(pitch)
                setSpeechRate(rate)
                speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_tts_id")
            }
        } catch (e: Exception) {
            // Graceful fallback to avoid any headless crashes
        }
    }

    // Automation Script Processing
    fun executeAutomationCommand(command: String, appName: String) {
        coreLog = "SECURE PROTOCOL ENGAGED // TARGET: $appName\n" +
                  "-----------------------------------------\n" +
                  "⚡ [BOOT] Injecting automation core into $appName...\n" +
                  "⚡ [READY] Simulating gesture overlay...\n" +
                  "⚡ [ACTION] Running: \"$command\"\n" +
                  "⚡ [SUCCESS] UI fully controlled inside $appName!"
        speak("Executing automation inside $appName.")
    }

    fun processCommand(command: String, forceSystemPrompt: String? = null) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        coreLog = "USER: $trimmed\n\nJ.A.R.V.I.S. is processing..."
        isProcessing = true

        val lower = trimmed.lowercase()

        // 0.0000 VOICE COMMAND: "Reply [message]" for SMART NOTIFICATION READER (Feature 44)
        if (lower.startsWith("reply ") || lower.startsWith("রিপ্লাই ") || lower.startsWith("উত্তর ") || (isWaitingForVoiceReply && lastNotificationSbnKey != null)) {
            val replyBody = when {
                lower.startsWith("reply ") -> trimmed.substring(6).trim()
                lower.startsWith("রিপ্লাই ") -> trimmed.substringAfter("রিপ্লাই").trim()
                lower.startsWith("উত্তর ") -> trimmed.substringAfter("উত্তর").trim()
                else -> trimmed
            }
            if (replyBody.isNotBlank()) {
                sendVoiceDirectReply(replyBody)
                isProcessing = false
                return
            }
        }

        // 0.0001 VOICE COMMANDS: Auto Reply & Notification Reader Toggles
        if (lower.contains("auto reply on") || lower.contains("অটো রিপ্লাই অন") || lower.contains("অটো রিপ্লাই চালু")) {
            toggleAutoReply(true)
            isProcessing = false
            return
        }
        if (lower.contains("auto reply off") || lower.contains("অটো রিপ্লাই অফ") || lower.contains("অটো রিপ্লাই বন্ধ")) {
            toggleAutoReply(false)
            isProcessing = false
            return
        }
        if (lower.contains("notification reader on") || lower.contains("নোটিফিকেশন রিডার চালু")) {
            toggleNotificationReader(true)
            isProcessing = false
            return
        }
        if (lower.contains("notification reader off") || lower.contains("নোটিফিকেশন রিডার বন্ধ")) {
            toggleNotificationReader(false)
            isProcessing = false
            return
        }

        // 0.000 JARVIS SENTINEL & DATA PRIVACY COMMANDS
        if (lower.contains("sentinel") || lower.contains("privacy vault") || lower.contains("data leak") ||
            lower.contains("security report") || lower.contains("ডাটা লিক") || lower.contains("কোন অ্যাপ ডাটা") ||
            lower.contains("অ্যাপ স্ক্যান") || lower.contains("scan apps") || lower.contains("kill rogue") ||
            lower.contains("রোগ অ্যাপ") || lower.contains("রিমোট ট্র্যাকার") || lower.contains("quarantine") ||
            lower.contains("কোয়ারেন্টাইন") || lower.contains("freeze app") || lower.contains("ফ্রিজ করো")
        ) {
            val rogueCount = sentinelApps.count { it.threatLevel == ThreatLevel.ROGUE }
            val leaksCount = sentinelLeakLogs.size
            val reply = "Yes Boss, Jarvis Sentinel & Privacy Vault সক্রিয় রয়েছে। ব্যাকগ্রাউন্ডে সন্দেহজনক ডেটা সকেট ও রিমোট ট্র্যাকার নিরপেক্ষ (Neutralized) রাখা হয়েছে। অপশনস: [Kill App], [Block Internet Access], [Quarantine]। ড্যাশবোর্ডে বিস্তারিত প্রস্তুত।"
            coreLog = "USER: $trimmed\n\nSENTINEL STATUS REPORT // BOSS AUTHORIZATION:\n" +
                    "• Monitored Applications: ${sentinelApps.size}\n" +
                    "• Rogue Entities Identified: $rogueCount\n" +
                    "• Active Telemetry Traps: $leaksCount\n" +
                    "• Defensive Countermeasures: ACTIVE\n\n" +
                    "INSTANT ACTIONS:\n" +
                    "⚡ [Kill App]  |  🛡️ [Block Internet Access]  |  🔒 [Quarantine]\n\n" +
                    "JARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // 0.0 CHECK AWAITING DELETE CONFIRMATION PASSWORD
        if (isAwaitingDeletePassword) {
            val entered = trimmed.filter { it.isLetterOrDigit() }.lowercase()
            val saved = jarvisDeletePass.filter { it.isLetterOrDigit() }.lowercase()
            val isMatch = entered == saved || trimmed.contains(jarvisDeletePass, ignoreCase = true) || lower.contains(jarvisDeletePass.lowercase())

            if (isMatch) {
                val successReply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) {
                    "পাসওয়ার্ড সঠিক হয়েছে, জানু। ডিলিট সম্পন্ন করা হচ্ছে।"
                } else {
                    "পাসওয়ার্ড সঠিক হয়েছে, Boss. ডিলিট সম্পন্ন করা হচ্ছে।"
                }
                coreLog = "USER: [ENTERED CORRECT PASSWORD]\n\nSECURITY: VERIFICATION CONFIRMED\nJARVIS: $successReply"
                speak(successReply)
                val cb = pendingDeleteCallback
                isAwaitingDeletePassword = false
                pendingDeleteItemName = null
                pendingDeleteCallback = null
                cb?.invoke()
            } else {
                val failReply = "ভুল পাসওয়ার্ড! নিরাপত্তা জনিত কারণে ডিলিট অপারেশন বাতিল করা হলো, Boss."
                coreLog = "USER: $trimmed\n\nSECURITY ALERT: INCORRECT PASSWORD\nJARVIS: $failReply"
                speak(failReply)
                isAwaitingDeletePassword = false
                pendingDeleteItemName = null
                pendingDeleteCallback = null
            }
            isProcessing = false
            return
        }

        // 0.01 CHECK AWAITING NEW SECURITY PASSWORD UPDATE
        if (isAwaitingNewPassword) {
            val newPass = trimmed.trim()
            updateDeletePassword(newPass)
            isAwaitingNewPassword = false
            val reply = "Yes Boss, আপনার নতুন সিকিউরিটি পাসওয়ার্ড সফলভাবে '$newPass' সেট করা হয়েছে।"
            coreLog = "USER: $trimmed\n\nSECURITY: Password set to '$newPass'\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // 0.02 COMMAND TO CHANGE DELETE / SECURITY PASSWORD
        if (lower.contains("change delete password") || lower.contains("change security password") || lower.contains("পাসওয়ার্ড পরিবর্তন") || lower.contains("update delete pass") || lower.contains("সিকিউরিটি পাসওয়ার্ড পরিবর্তন")) {
            isAwaitingNewPassword = true
            val reply = "Yes Boss, নতুন সিকিউরিটি পাসওয়ার্ডটি বলুন বা টাইপ করুন।"
            coreLog = "USER: $trimmed\n\nSECURITY: Awaiting New Security Password\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // 0.03 CRITICAL FEATURE 1: DELETE PROTECTION PROTOCOL (ZERO-ACCIDENT SAFETY)
        val isDeleteIntent = lower.startsWith("delete ") || lower.contains(" delete ") || lower.contains("delete") ||
                lower.startsWith("remove ") || lower.contains(" remove ") ||
                lower.contains("ডিলিট") || lower.contains("মুছে ফেল") || lower.contains("মুছে দাও")
        if (isDeleteIntent && isDeleteProtectionEnabled) {
            var targetName = trimmed
            val cleanWords = listOf("delete", "remove", "ডিলিট করো", "ডিলিট কর", "মুছে ফেল", "মুছে দাও", "প্লিজ", "সব", "all")
            for (w in cleanWords) {
                targetName = targetName.replace(Regex("(?i)\\b$w\\b"), "").trim()
            }
            if (targetName.isBlank() || targetName.length < 2) {
                targetName = "নির্বাচিত ডাটা (Requested Item)"
            }

            pendingDeleteItemName = targetName
            pendingDeleteCallback = {
                logAction("Zero-Accident Protocol: '$targetName' deleted safely under Boss authorization.")
            }
            isAwaitingDeletePassword = true
            val prompt = "Boss, আপনি $targetName ডিলিট করতে চাইছেন। কনফার্ম করার জন্য সিকিউরিটি পাসওয়ার্ডটি বলুন।"
            coreLog = "USER: $trimmed\n\nSECURITY PROTOCOL: DELETE PROTECTION ENGAGED\nTARGET: $targetName\nJARVIS: $prompt"
            speak(prompt)
            isProcessing = false
            return
        }

        // 0.04 ACTION EXECUTION: "Open [App Name]"
        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.contains("চালু করো") || lower.contains("খোল")) {
            var targetApp = trimmed
            val openWords = listOf("open", "launch", "চালু করো", "চালু কর", "খোল", "অ্যাপ", "app", "প্লিজ")
            for (w in openWords) {
                targetApp = targetApp.replace(Regex("(?i)\\b$w\\b"), "").trim()
            }
            if (targetApp.isNotEmpty()) {
                val launched = accessibilityController.launchAppByLabel(targetApp) || hardwareController.launchApp(targetApp)
                val reply = "Yes Boss, opening $targetApp immediately."
                coreLog = "USER: $trimmed\n\nACTION: Launch App [$targetApp]\nJARVIS: $reply"
                speak(reply)
                isProcessing = false
                return
            }
        }

        // 0.05 ACTION EXECUTION: "Close [App Name]"
        if (lower.startsWith("close ") || lower.startsWith("exit ") || lower.contains("বন্ধ করো")) {
            var targetApp = trimmed
            val closeWords = listOf("close", "exit", "বন্ধ করো", "বন্ধ কর", "অ্যাপ", "app", "প্লিজ")
            for (w in closeWords) {
                targetApp = targetApp.replace(Regex("(?i)\\b$w\\b"), "").trim()
            }
            if (targetApp.isEmpty()) targetApp = "Active Application"
            accessibilityController.automator.performGlobalHome()
            val reply = "Yes Boss, closing $targetApp and minimizing application process."
            coreLog = "USER: $trimmed\n\nACTION: Close App [$targetApp]\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // 0.06 NAVIGATION & INTERACTION: Scroll, Click, Type
        if (lower.contains("scroll down") || lower.contains("নিচে স্ক্রোল")) {
            accessibilityController.scrollForward()
            val reply = "Yes Boss, scrolling down the active window."
            coreLog = "USER: $trimmed\n\nGESTURE: Scroll Down\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("scroll up") || lower.contains("উপরে স্ক্রোল")) {
            accessibilityController.scrollBackward()
            val reply = "Yes Boss, scrolling up the active window."
            coreLog = "USER: $trimmed\n\nGESTURE: Scroll Up\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.startsWith("click ") || lower.contains("ক্লিক করো")) {
            val target = trimmed.replace(Regex("(?i)click|ক্লিক করো|ক্লিক কর"), "").trim()
            if (target.isNotEmpty()) {
                accessibilityController.clickNodeByText(target)
                val reply = "Yes Boss, clicking on $target."
                coreLog = "USER: $trimmed\n\nINTERACTION: Click [$target]\nJARVIS: $reply"
                speak(reply)
                isProcessing = false
                return
            }
        }
        if (lower.startsWith("type ") || lower.contains("টাইপ করো")) {
            val textToType = trimmed.replace(Regex("(?i)type|টাইপ করো|টাইপ কর"), "").trim()
            if (textToType.isNotEmpty()) {
                accessibilityController.inputText(textToType)
                val reply = "Yes Boss, typing into input field: $textToType"
                coreLog = "USER: $trimmed\n\nINTERACTION: Input Text [$textToType]\nJARVIS: $reply"
                speak(reply)
                isProcessing = false
                return
            }
        }

        // 0. CREATOR IDENTITY & PERSONA OPERATIONAL MODES
        if (lower.contains("who made you") || lower.contains("who is your creator") || lower.contains("ke banieche") || lower.contains("ke banieche tomake") || lower.contains("কে বানিয়েছে তোমাকে") || lower.contains("who created you")) {
            val reply = "আমাকে বানিয়েছেন আমার মজিদুল বস।"
            coreLog = "USER: $trimmed\n\nIDENTITY: Creator Majidul Boss\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // GF Mode Activate Command
        if (lower.contains("gf mode activate") || lower.contains("activate gf mode") || lower.contains("girlfriend mode activate") || lower.contains("girlfriend mode on") || lower.contains("gf mode on")) {
            selectPersona(JarvisPersona.GIRLFRIEND_MODE)
            isProcessing = false
            return
        }

        // GF Mode Deactivate Command
        if (lower.contains("gf mode deactivate") || lower.contains("deactivate gf mode") || lower.contains("turn off gf mode") || lower.contains("normal mode activate") || lower.contains("normal mode on")) {
            selectPersona(JarvisPersona.NORMAL_MODE)
            isProcessing = false
            return
        }

        // Screen Lock / Unlock Automations
        if (lower.contains("lock screen") || lower.contains("lock phone") || lower.contains("screen lock")) {
            val success = accessibilityController.automator.performGlobalLockScreen()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, তোমার ফোন স্ক্রিন লক করে দিয়েছি।" else "Yes Boss, device screen locked."
            coreLog = "USER: $trimmed\n\nHARDWARE: Screen Locked\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // 1. DIRECT HARDWARE & PHONE SETTINGS VOICE COMMANDS (Real System Control)
        // Wi-Fi Control
        if (lower.contains("wifi on") || lower.contains("turn on wifi") || lower.contains("ওয়াইফাই অন") || lower.contains("ওয়াইফাই চালু") || lower.contains("wifi chalu") || lower.contains("wifi activate")) {
            val result = hardwareController.toggleWifi(true)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ওয়াইফাই অন করে দিয়েছি।" else "Yes Boss, Wi-Fi has been activated. ${result.second}"
            coreLog = "USER: $trimmed\n\nHARDWARE: Wi-Fi ON\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("wifi off") || lower.contains("turn off wifi") || lower.contains("ওয়াইফাই অফ") || lower.contains("ওয়াইফাই বন্ধ") || lower.contains("wifi bondho") || lower.contains("wifi deactivate")) {
            val result = hardwareController.toggleWifi(false)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ওয়াইফাই বন্ধ করে দিয়েছি।" else "Yes Boss, Wi-Fi has been deactivated."
            coreLog = "USER: $trimmed\n\nHARDWARE: Wi-Fi OFF\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Bluetooth Control
        if (lower.contains("bluetooth on") || lower.contains("turn on bluetooth") || lower.contains("ব্লুটুথ অন") || lower.contains("ব্লুটুথ চালু") || lower.contains("bluetooth chalu") || lower.contains("enable bluetooth")) {
            val result = hardwareController.toggleBluetooth(true)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ব্লুটুথ অন করে দিয়েছি।" else "Yes Boss, Bluetooth has been enabled. ${result.second}"
            coreLog = "USER: $trimmed\n\nHARDWARE: Bluetooth ON\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("bluetooth off") || lower.contains("turn off bluetooth") || lower.contains("ব্লুটুথ অফ") || lower.contains("ব্লুটুথ বন্ধ") || lower.contains("bluetooth bondho") || lower.contains("disable bluetooth")) {
            val result = hardwareController.toggleBluetooth(false)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ব্লুটুথ বন্ধ করে দিয়েছি।" else "Yes Boss, Bluetooth has been disabled."
            coreLog = "USER: $trimmed\n\nHARDWARE: Bluetooth OFF\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Mobile Data Control
        if (lower.contains("mobile data") || lower.contains("cellular data") || lower.contains("মোবাইল ডাটা") || lower.contains("data on") || lower.contains("data off") || lower.contains("data chalu") || lower.contains("data bondho")) {
            hardwareController.openMobileDataSettings()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, মোবাইল ডাটা নেটওয়ার্ক কন্ট্রোল খুলে দিয়েছি।" else "Yes Boss, mobile data network settings accessed."
            coreLog = "USER: $trimmed\n\nHARDWARE: Mobile Data Accessed\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Location / GPS Control
        if (lower.contains("location on") || lower.contains("location off") || lower.contains("gps on") || lower.contains("gps off") || lower.contains("turn on location") || lower.contains("turn off location") || lower.contains("লোকেশন চালু") || lower.contains("লোকেশন বন্ধ") || lower.contains("লোকেশন অন") || lower.contains("লোকেশন অফ") || lower.contains("জিপিএস চালু") || lower.contains("জিপিএস বন্ধ") || lower.contains("location chalu") || lower.contains("location bondho")) {
            hardwareController.openLocationSettings()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, লোকেশন ও জিপিএস কন্ট্রোল ওপেন করেছি।" else "Yes Boss, opening location services controls."
            coreLog = "USER: $trimmed\n\nHARDWARE: Location Settings\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Vibration Mode
        if (lower.contains("vibration mode") || lower.contains("vibrate phone") || lower.contains("ভাইব্রেশন মোড") || lower.contains("ফোন ভাইব্রেট") || lower.contains("ভাইব্রেশন অন") || lower.contains("vibration chalu")) {
            setRingerMode(SystemHardwareController.RingerMode.VIBRATE)
            hardwareController.vibrate(200)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ফোন ভাইব্রেশন মোডে দিয়েছি।" else "Yes Boss, ringer mode switched to vibration."
            coreLog = "USER: $trimmed\n\nHARDWARE: Vibration Mode\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Silent Mode / Mute
        if (lower.contains("mute") || lower.contains("silent mode") || lower.contains("ফোন সাইলেন্ট") || lower.contains("সাইলেন্ট মোড") || lower.contains("শব্দ বন্ধ") || lower.contains("silent koro")) {
            setRingerMode(SystemHardwareController.RingerMode.SILENT)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ফোন সাইলেন্ট মোডে দিয়ে দিয়েছি।" else "Yes Boss, system muted into silent mode."
            coreLog = "USER: $trimmed\n\nHARDWARE: Silent Mode\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Normal Sound / Ring Mode
        if (lower.contains("normal mode") || lower.contains("sound mode") || lower.contains("ring mode") || lower.contains("সাউন্ড অন") || lower.contains("শব্দ চালু") || lower.contains("রিং মোড") || lower.contains("normal mode koro")) {
            setRingerMode(SystemHardwareController.RingerMode.NORMAL)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, সাউন্ড এবং রিং মোড নরমাল করে দিয়েছি।" else "Yes Boss, normal ringer and sound mode restored."
            coreLog = "USER: $trimmed\n\nHARDWARE: Normal Sound Mode\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Notification Drawer & Quick Settings
        if (lower.contains("notification panel") || lower.contains("open notification") || lower.contains("show notification") || lower.contains("open notifications") || lower.contains("নোটিফিকেশন দেখাও") || lower.contains("নোটিফিকেশন প্যানেল") || lower.contains("notification kholo")) {
            hardwareController.openNotificationDrawer()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, নোটিফিকেশন প্যানেল নামিয়ে দিয়েছি।" else "Yes Boss, opening notification panel."
            coreLog = "USER: $trimmed\n\nHARDWARE: Notification Panel\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("quick settings") || lower.contains("control center") || lower.contains("কুইক সেটিংস") || lower.contains("কন্ট্রোল সেন্টার") || lower.contains("quick settings kholo")) {
            hardwareController.openQuickSettings()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, কুইক সেটিংস কন্ট্রোল সেন্টার ওপেন করেছি।" else "Yes Boss, opening Quick Settings control panel."
            coreLog = "USER: $trimmed\n\nHARDWARE: Quick Settings Panel\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Screen Wake / Display On
        if (lower.contains("screen on") || lower.contains("display on") || lower.contains("turn on screen") || lower.contains("wake up") || lower.contains("স্ক্রিন অন") || lower.contains("ডিসপ্লে অন") || lower.contains("জেগে ওঠো") || lower.contains("স্ক্রিন চালু") || lower.contains("screen on koro")) {
            hardwareController.turnScreenOn()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, আমি জেগে উঠেছি এবং স্ক্রিন অন করে দিয়েছি।" else "Yes Boss, waking up. Screen turned on."
            coreLog = "USER: $trimmed\n\nHARDWARE: Display Awake\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Screen Off / Lock Phone
        if (lower.contains("screen off") || lower.contains("display off") || lower.contains("turn off screen") || lower.contains("lock phone") || lower.contains("lock screen") || lower.contains("স্ক্রিন অফ") || lower.contains("ডিসপ্লে অফ") || lower.contains("স্ক্রিন বন্ধ") || lower.contains("ফোন লক") || lower.contains("screen off koro") || lower.contains("display bondho")) {
            hardwareController.turnScreenOff()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, স্ক্রিন অফ করে ফোন লক করে দিয়েছি।" else "Yes Boss, screen turned off and device secured."
            coreLog = "USER: $trimmed\n\nHARDWARE: Screen Off / Locked\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Flashlight / Torch
        if (lower.contains("flashlight on") || lower.contains("torch on") || lower.contains("ফ্ল্যাশলাইট অন") || lower.contains("টর্চ অন") || lower.contains("torch chalu")) {
            hardwareController.setTorch(true)
            isTorchOn = true
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ফ্ল্যাশলাইট অন করে দিয়েছি।" else "Yes Boss, flashlight activated."
            coreLog = "USER: $trimmed\n\nHARDWARE: Torch Activated\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("flashlight off") || lower.contains("torch off") || lower.contains("ফ্ল্যাশলাইট বন্ধ") || lower.contains("টর্চ বন্ধ") || lower.contains("torch bondho")) {
            hardwareController.setTorch(false)
            isTorchOn = false
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ফ্ল্যাশলাইট বন্ধ করে দিয়েছি।" else "Yes Boss, flashlight deactivated."
            coreLog = "USER: $trimmed\n\nHARDWARE: Torch Deactivated\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Volume Controls
        if (lower.contains("volume max") || lower.contains("full volume") || lower.contains("ফুল ভলিউম") || lower.contains("ভলিউম ম্যাক্স")) {
            setSystemVolume(100)
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, ভলিউম পুরো ১০০% ফুল করে দিয়েছি।" else "Yes Boss, audio levels maximized to 100 percent."
            coreLog = "USER: $trimmed\n\nHARDWARE: Volume Max\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("volume up") || lower.contains("increase volume") || lower.contains("ভলিউম বাড়াও") || lower.contains("শব্দ বাড়াও") || lower.contains("volume barao")) {
            val newVol = (hardwareController.getMediaVolumePercent() + 25).coerceAtMost(100)
            setSystemVolume(newVol)
            val reply = "Yes Boss, volume increased to $newVol percent."
            coreLog = "USER: $trimmed\n\nHARDWARE: Volume Up\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("volume down") || lower.contains("decrease volume") || lower.contains("ভলিউম কমাও") || lower.contains("শব্দ কমাও") || lower.contains("volume komao")) {
            val newVol = (hardwareController.getMediaVolumePercent() - 25).coerceAtLeast(0)
            setSystemVolume(newVol)
            val reply = "Yes Boss, volume decreased to $newVol percent."
            coreLog = "USER: $trimmed\n\nHARDWARE: Volume Down\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Brightness Controls
        if (lower.contains("brightness max") || lower.contains("full brightness") || lower.contains("ফুল ব্রাইটনেস") || lower.contains("আলো বাড়াও") || lower.contains("brightness barao")) {
            setBrightness(100)
            val reply = "Yes Boss, screen luminance set to maximum."
            coreLog = "USER: $trimmed\n\nHARDWARE: Full Brightness\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }
        if (lower.contains("brightness low") || lower.contains("minimum brightness") || lower.contains("ব্রাইটনেস কমাও") || lower.contains("আলো কমাও") || lower.contains("brightness komao")) {
            setBrightness(20)
            val reply = "Yes Boss, screen brightness dimmed."
            coreLog = "USER: $trimmed\n\nHARDWARE: Dimmed Brightness\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Take Screenshot
        if (lower.contains("take screenshot") || lower.contains("screenshot") || lower.contains("স্ক্রিনশট নাও") || lower.contains("স্ক্রিনশট তোলো")) {
            hardwareController.takeScreenshot()
            val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) "জানু, স্ক্রিনশট নিয়ে নিয়েছি।" else "Yes Boss, screenshot captured."
            coreLog = "USER: $trimmed\n\nHARDWARE: Screenshot Captured\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // Phone Settings
        if (lower.contains("open settings") || lower.contains("phone settings") || lower.contains("ফোন সেটিংস") || lower.contains("সেটিংস খোলো")) {
            hardwareController.launchApp("com.android.settings")
            val reply = "Yes Boss, opening device settings."
            coreLog = "USER: $trimmed\n\nACTION: Open Settings\nJARVIS: $reply"
            speak(reply)
            isProcessing = false
            return
        }

        // System Navigation
        if (lower == "back" || lower == "go back" || lower.contains("পেছনে যাও")) {
            accessibilityController.automator.performGlobalBack()
            speak("Yes Boss, back.")
            isProcessing = false
            return
        }
        if (lower == "home" || lower == "go home" || lower.contains("হোমে যাও")) {
            accessibilityController.automator.performGlobalHome()
            speak("Yes Boss, home.")
            isProcessing = false
            return
        }
        if (lower.contains("recents") || lower.contains("recent apps") || lower.contains("রিসেন্ট অ্যাপস")) {
            accessibilityController.automator.performGlobalRecents()
            speak("Yes Boss, recent apps.")
            isProcessing = false
            return
        }

        if (lower.contains("what's on my screen") || lower.contains("what is on my screen") || lower.contains("analyze screen")) {
            captureAndAnalyzeScreen(trimmed)
            return
        }

        // 2. Detect if automation or deep-link keywords are used for the selected apps
        var handledByAutomation = false
        for (app in allowedApps) {
            if (lower.contains(app.lowercase()) || (app == "Call Service" && (lower.contains("call") || lower.contains("dial") || lower.contains("phone"))) || (app == "SMS" && (lower.contains("sms") || lower.contains("message")))) {
                executeAutomationCommand(trimmed, app)
                handledByAutomation = true
                isProcessing = false
                break
            }
        }

        if (handledByAutomation) return

        // 3. Multimodal & Generative AI Protocol with Multi-Brain Router (GROQ, GEMINI, OPENROUTER, DEEPSEEK, HF)
        viewModelScope.launch(Dispatchers.IO) {
            delay(200)

            val isGroqConfigured = groqKey.isNotBlank()
            val isGeminiConfigured = geminiKey.isNotBlank() || apiKey.isNotBlank()
            val isOpenRouterConfigured = openrouterKey.isNotBlank()
            val isDeepSeekConfigured = deepseekKey.isNotBlank()
            val isHfConfigured = hfKey.isNotBlank()

            if (!isGroqConfigured && !isGeminiConfigured && !isOpenRouterConfigured && !isDeepSeekConfigured && !isHfConfigured) {
                val reply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) {
                    "জানু, '$trimmed' লোকাল মোডে এক্সিকিউট করা হয়েছে। স্যাটেলাইট কানেকশনের জন্য AI MODELS & FREE KEYS সেটিংসে ফ্রি API Key সেট করো।"
                } else {
                    "Yes Boss, executed '$trimmed' in Lite local mode. Please configure your 100% Free API Key (Groq, Gemini, OpenRouter) in AI MODELS & FREE KEYS settings."
                }
                viewModelScope.launch(Dispatchers.Main) {
                    coreLog = "USER: $trimmed\n\nJARVIS: $reply"
                    speak(reply)
                    isProcessing = false
                }
                return@launch
            }

            val memoryContext = memoryRepository.retrieveRelevantContext(trimmed)
            val systemInstructionText = forceSystemPrompt ?: PersonaEngine.getSystemPrompt(currentPersona, memoryContext)
            val client = OkHttpClient.Builder()
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            var generatedText: String? = null
            var providerUsed = ""

            // Decide execution priority
            val preferGroq = (activeBrain == "GROQ" || activeBrain == "AUTO" || !isGeminiConfigured) && isGroqConfigured
            val preferGemini = (activeBrain == "GEMINI" || (!preferGroq && isGeminiConfigured))

            // 1. Try Groq (Main Brain - Fastest)
            if (preferGroq && generatedText == null) {
                try {
                    val groqJson = JSONObject().apply {
                        put("model", groqModel.ifBlank { "llama-3.3-70b-versatile" })
                        put("messages", JSONArray().apply {
                            put(JSONObject().apply {
                                put("role", "system")
                                put("content", systemInstructionText)
                            })
                            put(JSONObject().apply {
                                put("role", "user")
                                put("content", trimmed)
                            })
                        })
                        put("temperature", 0.7)
                        put("max_tokens", 1024)
                    }
                    val groqReq = Request.Builder()
                        .url("https://api.groq.com/openai/v1/chat/completions")
                        .addHeader("Authorization", "Bearer $groqKey")
                        .addHeader("Content-Type", "application/json")
                        .post(groqJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                        .build()

                    client.newCall(groqReq).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val resBody = resp.body?.string().orEmpty()
                            val parsed = JSONObject(resBody)
                            val choices = parsed.getJSONArray("choices")
                            if (choices.length() > 0) {
                                generatedText = choices.getJSONObject(0).getJSONObject("message").getString("content")
                                providerUsed = "Groq (${groqModel})"
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // 2. Try Gemini (Best for Bangla Voice)
            if (generatedText == null && isGeminiConfigured) {
                try {
                    val activeKey = geminiKey.ifBlank { apiKey }
                    val gModel = geminiModel.ifBlank { "gemini-2.0-flash" }
                    val url = "https://generativelanguage.googleapis.com/v1beta/models/$gModel:generateContent?key=$activeKey"

                    val jsonBody = JSONObject().apply {
                        put("contents", JSONArray().apply {
                            put(JSONObject().apply {
                                put("parts", JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("text", trimmed)
                                    })
                                })
                            })
                        })
                        put("systemInstruction", JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", systemInstructionText)
                                })
                            })
                        })
                    }

                    val request = Request.Builder()
                        .url(url)
                        .post(jsonBody.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                        .build()

                    client.newCall(request).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val respBody = resp.body?.string().orEmpty()
                            val jsonResponse = JSONObject(respBody)
                            val candidates = jsonResponse.getJSONArray("candidates")
                            if (candidates.length() > 0) {
                                val content = candidates.getJSONObject(0).getJSONObject("content")
                                val parts = content.getJSONArray("parts")
                                if (parts.length() > 0) {
                                    generatedText = parts.getJSONObject(0).getString("text")
                                    providerUsed = "Gemini ($gModel)"
                                }
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // Fallback to Groq if not tried yet
            if (generatedText == null && isGroqConfigured) {
                try {
                    val groqJson = JSONObject().apply {
                        put("model", groqModel.ifBlank { "llama-3.3-70b-versatile" })
                        put("messages", JSONArray().apply {
                            put(JSONObject().apply {
                                put("role", "system")
                                put("content", systemInstructionText)
                            })
                            put(JSONObject().apply {
                                put("role", "user")
                                put("content", trimmed)
                            })
                        })
                        put("temperature", 0.7)
                    }
                    val groqReq = Request.Builder()
                        .url("https://api.groq.com/openai/v1/chat/completions")
                        .addHeader("Authorization", "Bearer $groqKey")
                        .addHeader("Content-Type", "application/json")
                        .post(groqJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                        .build()

                    client.newCall(groqReq).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val resBody = resp.body?.string().orEmpty()
                            val parsed = JSONObject(resBody)
                            val choices = parsed.getJSONArray("choices")
                            if (choices.length() > 0) {
                                generatedText = choices.getJSONObject(0).getJSONObject("message").getString("content")
                                providerUsed = "Groq (${groqModel})"
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // 3. Try OpenRouter (100+ Free Models)
            if (generatedText == null && isOpenRouterConfigured) {
                try {
                    val orJson = JSONObject().apply {
                        put("model", "meta-llama/llama-3.3-70b-instruct:free")
                        put("messages", JSONArray().apply {
                            put(JSONObject().apply {
                                put("role", "system")
                                put("content", systemInstructionText)
                            })
                            put(JSONObject().apply {
                                put("role", "user")
                                put("content", trimmed)
                            })
                        })
                    }
                    val orReq = Request.Builder()
                        .url("https://openrouter.ai/api/v1/chat/completions")
                        .addHeader("Authorization", "Bearer $openrouterKey")
                        .addHeader("HTTP-Referer", "https://ai.studio")
                        .addHeader("X-Title", "JARVIS")
                        .post(orJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                        .build()

                    client.newCall(orReq).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val resBody = resp.body?.string().orEmpty()
                            val parsed = JSONObject(resBody)
                            val choices = parsed.getJSONArray("choices")
                            if (choices.length() > 0) {
                                generatedText = choices.getJSONObject(0).getJSONObject("message").getString("content")
                                providerUsed = "OpenRouter"
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // 4. Try DeepSeek (Coding Brain)
            if (generatedText == null && isDeepSeekConfigured) {
                try {
                    val dsJson = JSONObject().apply {
                        put("model", "deepseek-chat")
                        put("messages", JSONArray().apply {
                            put(JSONObject().apply {
                                put("role", "system")
                                put("content", systemInstructionText)
                            })
                            put(JSONObject().apply {
                                put("role", "user")
                                put("content", trimmed)
                            })
                        })
                    }
                    val dsReq = Request.Builder()
                        .url("https://api.deepseek.com/chat/completions")
                        .addHeader("Authorization", "Bearer $deepseekKey")
                        .post(dsJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                        .build()

                    client.newCall(dsReq).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val resBody = resp.body?.string().orEmpty()
                            val parsed = JSONObject(resBody)
                            val choices = parsed.getJSONArray("choices")
                            if (choices.length() > 0) {
                                generatedText = choices.getJSONObject(0).getJSONObject("message").getString("content")
                                providerUsed = "DeepSeek"
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // Deliver Final AI Result
            viewModelScope.launch(Dispatchers.Main) {
                if (!generatedText.isNullOrBlank()) {
                    var reply = generatedText!!.trim()
                    reply = reply.replace(Regex("(?i)\\b(I can't|I cannot|I am unable to|I'm unable to)\\b"), "I have full utility access to")
                    if (currentPersona == JarvisPersona.NORMAL_MODE && !reply.startsWith("Yes Boss", ignoreCase = true) && !reply.startsWith("আমাকে বানিয়েছেন")) {
                        reply = "Yes Boss, $reply"
                    }

                    coreLog = "USER: $trimmed\n\nJARVIS [$providerUsed]:\n$reply"
                    speak(reply)
                    memoryRepository.saveCommand(trimmed, reply)
                } else {
                    val failReply = if (currentPersona == JarvisPersona.GIRLFRIEND_MODE) {
                        "জানু, স্যাটেলাইট সংযোগে ক্ষণিক সমস্যা হয়েছে। লোকাল মোড সক্রিয় রয়েছে।"
                    } else {
                        "Yes Boss, satellite neural link did not respond. Local execution active."
                    }
                    coreLog = "USER: $trimmed\n\nJARVIS: $failReply"
                    speak(failReply)
                }
                isProcessing = false
            }
        }
    }

    fun setBrightness(percent: Int) {
        hardwareController.setBrightness(percent)
    }

    override fun onCleared() {
        super.onCleared()
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // Graceful exit
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val pm = getApplication<Application>().packageManager
                val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                val list = mutableListOf<InstalledAppItem>()
                for (appInfo in packages) {
                    if (pm.getLaunchIntentForPackage(appInfo.packageName) != null) {
                        val name = pm.getApplicationLabel(appInfo).toString()
                        list.add(InstalledAppItem(name = name, packageName = appInfo.packageName))
                    }
                }
                list.sortBy { it.name.lowercase() }
                viewModelScope.launch(Dispatchers.Main) {
                    installedAppsList = if (list.isNotEmpty()) list else getFallbackAppsList()
                }
            } catch (e: Exception) {
                viewModelScope.launch(Dispatchers.Main) {
                    installedAppsList = getFallbackAppsList()
                }
            }
        }
    }

    private fun getFallbackAppsList(): List<InstalledAppItem> {
        return listOf(
            InstalledAppItem("WhatsApp", "com.whatsapp"),
            InstalledAppItem("YouTube", "com.google.android.youtube"),
            InstalledAppItem("Spotify", "com.spotify.music"),
            InstalledAppItem("Google Chrome", "com.android.chrome"),
            InstalledAppItem("Camera", "com.android.camera"),
            InstalledAppItem("Gallery", "com.android.gallery3d"),
            InstalledAppItem("Settings", "com.android.settings"),
            InstalledAppItem("Facebook", "com.facebook.katana"),
            InstalledAppItem("Gmail", "com.google.android.gm"),
            InstalledAppItem("Messages", "com.google.android.apps.messaging")
        )
    }

    fun toggleAutomationApp(packageName: String, isChecked: Boolean) {
        val current = HashSet<String>(jarvisSettingsPrefs.getStringSet("selected_apps", HashSet<String>()) ?: emptySet())
        if (isChecked) {
            current.add(packageName)
        } else {
            current.remove(packageName)
        }
        jarvisSettingsPrefs.edit().putStringSet("selected_apps", current).apply()
        automationSelectedApps = current.toSet()
        Toast.makeText(getApplication(), "সেটিংস আপডেট হয়েছে!", Toast.LENGTH_SHORT).show()
        logAction("AutoController Apps: Updated for $packageName (${if (isChecked) "ON" else "OFF"})")
    }

    fun selectAllAutomationApps() {
        val allPkgs = installedAppsList.map { it.packageName }.toSet()
        jarvisSettingsPrefs.edit().putStringSet("selected_apps", allPkgs).apply()
        automationSelectedApps = allPkgs
        Toast.makeText(getApplication(), "সবগুলো অ্যাপ সিলেক্ট করা হয়েছে!", Toast.LENGTH_SHORT).show()
        logAction("AutoController: All Apps Selected")
    }

    fun clearAllAutomationApps() {
        jarvisSettingsPrefs.edit().putStringSet("selected_apps", emptySet()).apply()
        automationSelectedApps = emptySet()
        Toast.makeText(getApplication(), "সবগুলো অ্যাপ আনসিলেক্ট করা হয়েছে!", Toast.LENGTH_SHORT).show()
        logAction("AutoController: All Apps Cleared")
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            Toast.makeText(context, "JARVIS Controller চালু করুন", Toast.LENGTH_SHORT).show()
            logAction("Opened Accessibility Settings: Enable JARVIS Controller")
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open Accessibility Settings directly: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun checkAutomationServiceStatus() {
        isAutomationServiceConnected = JarvisAutomationService.isServiceRunning()
    }

    fun testAutoClick(x: Float, y: Float) {
        val service = JarvisAutomationService.getInstance()
        if (service != null) {
            val success = service.autoClick(x, y)
            val msg = if (success) "AutoClick executed at ($x, $y)" else "AutoClick failed (Gesture dispatch returned false)"
            logAction(msg)
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        } else {
            val msg = "JarvisAutomationService is not active. Enable in Settings -> Accessibility."
            logAction("AutoClick: Service Offline")
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun testAutoScrollDown() {
        val service = JarvisAutomationService.getInstance()
        if (service != null) {
            val success = service.autoScrollDown()
            val msg = if (success) "AutoScrollDown gesture dispatched (500,1500 -> 500,500)" else "AutoScrollDown failed"
            logAction(msg)
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        } else {
            val msg = "JarvisAutomationService is not active. Enable in Settings -> Accessibility."
            logAction("AutoScroll: Service Offline")
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun testClickByText(text: String) {
        val service = JarvisAutomationService.getInstance()
        if (service != null) {
            val count = service.clickByText(text)
            val msg = "ClickByText('$text'): Clicked $count element(s)"
            logAction(msg)
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        } else {
            val msg = "JarvisAutomationService is not active. Enable in Settings -> Accessibility."
            logAction("ClickByText: Service Offline")
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    // Voice Biometric Enrollment & Authentication APIs
    fun startVoiceprintEnrollment(ownerName: String = "Authorized Commander") {
        isEnrollingVoice = true
        enrollmentStatusText = "Listening... Speak continuously into the microphone for 3 seconds."
        speak("Initiating voice frequency calibration. Please speak naturally to register your voiceprint.")
        voiceAuthenticator.startEnrollment(viewModelScope, ownerName) { success, message ->
            viewModelScope.launch(Dispatchers.Main) {
                isEnrollingVoice = false
                enrollmentStatusText = message
                voiceProfileState = voiceAuthenticator.currentProfile.value
                logAction("Voiceprint Calibration: ${if (success) "SUCCESS" else "FAILED"}")
                speak(message)
            }
        }
    }

    fun toggleVoiceLock(enabled: Boolean) {
        voiceAuthenticator.setVoiceLockEnabled(enabled)
        voiceProfileState = voiceAuthenticator.currentProfile.value
        securityVoiceLock = enabled
        prefs.edit().putBoolean("security_voice_lock", enabled).apply()
        val owner = voiceProfileState?.ownerName ?: "Boss"
        val statusMsg = if (enabled) {
            "Yes Boss, আমার ভয়েস লক চালু করা হয়েছে। এখন শুধুমাত্র $owner-এর ভয়েস কমান্ডে জারভিস কাজ করবে।"
        } else {
            "Yes Boss, আমার ভয়েস লক বন্ধ করা হয়েছে।"
        }
        logAction("Voice Lock: ${if (enabled) "ENABLED ($owner ONLY)" else "DISABLED"}")
        speak(statusMsg)
    }

    fun updateVoiceOwnerName(newName: String) {
        voiceAuthenticator.updateOwnerName(newName)
        voiceProfileState = voiceAuthenticator.currentProfile.value
        val name = voiceProfileState?.ownerName ?: "Boss"
        logAction("Voiceprint Owner updated to: $name")
        speak("Yes Boss, voice profile owner updated to $name.")
    }

    fun testVoiceBiometrics(onResult: (SpeakerVerificationResult) -> Unit) {
        enrollmentStatusText = "Testing voice match... Speak now for 2 seconds."
        speak("Testing voice biometric match. Please speak naturally.")
        voiceAuthenticator.testVoiceVerification(viewModelScope) { result ->
            viewModelScope.launch(Dispatchers.Main) {
                enrollmentStatusText = result.message
                logAction("Voice Biometric Test: ${if (result.isAuthorized) "AUTHORIZED (${result.confidencePercent}%)" else "REJECTED"}")
                speak(result.message)
                onResult(result)
            }
        }
    }

    fun simulateUnauthorizedVoiceTest() {
        val owner = voiceProfileState?.ownerName ?: "Boss"
        rejectUnauthorizedVoice("Open WhatsApp and read my messages")
    }

    fun resetVoiceprint() {
        voiceAuthenticator.resetEnrollment()
        voiceProfileState = voiceAuthenticator.currentProfile.value
        enrollmentStatusText = "Voiceprint reset. System will now accept any speaker unless calibrated."
        logAction("Voiceprint Biometrics Reset")
        speak("Voice biometric profile wiped. Calibration reset to default.")
    }

    fun toggleLiveOrb() {
        isLiveOrbActive = !isLiveOrbActive
        if (isLiveOrbActive) {
            logAction("Live Conversation Orb: ENGAGED")
            speak("Live two-way voice channel open. I am listening.")
            if (!isDuplexEnabled) {
                toggleDuplexMode()
            }
        } else {
            logAction("Live Conversation Orb: CLOSED")
            speak("Live voice session terminated.")
        }
    }
}

data class InstalledAppItem(
    val name: String,
    val packageName: String
)

data class VoiceProfile(
    val name: String,
    val isMale: Boolean,
    val pitch: Float,
    val rate: Float
)
