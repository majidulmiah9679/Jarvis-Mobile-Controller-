package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.persona.JarvisPersona
import com.example.ui.theme.*

// ENUM & FOLDER STACK FOR SETTINGS REORGANIZATION (VARIATION 01)
enum class SettingsFolder(val title: String, val subtitle: String) {
    ACCOUNT_PROFILE("ACCOUNT & PROFILE", "Master Identity, Credentials & Voice Biometrics"),
    NOTIFICATIONS("NOTIFICATIONS", "AI Multi-Brain, Auto Reply (36) & Smart Reader (44)"),
    PRIVACY_SECURITY("PRIVACY & SECURITY", "Sentinel Vault, 253 Apps Audited & Defensive Shield"),
    DISPLAY_APPEARANCE("DISPLAY & APPEARANCE", "Theme Mode (Light/Dark), Live HUD & Display"),
    STORAGE_DATA("STORAGE & DATA", "Room SQL Memory, Daemon & System Automation")
}

@Composable
fun SettingsFolderItemRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isDark: Boolean,
    onClick: () -> Unit
) {
    val textColor = if (isDark) Color.White else Color(0xFF1A2332)
    val accentColor = if (isDark) Color(0xFF00F5FF) else Color(0xFF0078FF)
    val dividerColor = if (isDark) Color(0xFF1A2332) else Color(0xFFE0E6ED)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Text(
                    text = title,
                    color = textColor,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Open $title",
                tint = accentColor,
                modifier = Modifier.size(22.dp)
            )
        }

        Divider(color = dividerColor, thickness = 1.dp)
    }
}

// TAB 3: SETTINGS SCREEN (VARIATION 01 - FOLDER STACK)
@Composable
fun JarvisSettingsScreen(viewModel: JarvisViewModel) {
    val context = LocalContext.current
    val isDark = viewModel.isDarkTheme
    val isLiveMode = viewModel.isLiveMode
    val selectedVoiceName = viewModel.selectedVoiceName
    val allowedApps = viewModel.allowedApps

    val bgColor by animateColorAsState(
        targetValue = if (isDark) Color(0xFF080B14) else Color(0xFFF5F7FB),
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "settings_bg"
    )
    val cardBgColor by animateColorAsState(
        targetValue = if (isDark) Color(0xFF0A1526) else Color.White,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "settings_card_bg"
    )
    val textColorPrimary by animateColorAsState(
        targetValue = if (isDark) Color.White else Color(0xFF1A2332),
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "text_primary"
    )
    val textColorSecondary by animateColorAsState(
        targetValue = if (isDark) HoloTextSecondary else Color(0xFF5A6E85),
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "text_secondary"
    )
    val cyanAccent by animateColorAsState(
        targetValue = if (isDark) Color(0xFF00F5FF) else Color(0xFF0078FF),
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "cyan_accent"
    )
    val dividerColor by animateColorAsState(
        targetValue = if (isDark) Color(0xFF1A2332) else Color(0xFFE0E6ED),
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "divider_color"
    )

    var activeFolder by remember { mutableStateOf<SettingsFolder?>(null) }

    BackHandler(enabled = activeFolder != null) {
        activeFolder = null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        // TOP HEADER: Back Arrow (<-) + Text "SETTINGS" in cyan + Gear icon top right
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        if (activeFolder != null) {
                            activeFolder = null
                        } else {
                            viewModel.selectTab(0)
                        }
                    },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = cyanAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Text(
                    text = activeFolder?.title ?: "SETTINGS",
                    color = cyanAccent,
                    fontSize = 17.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            IconButton(
                onClick = {
                    Toast.makeText(context, "J.A.R.V.I.S. Core v2.4.1 Active", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = cyanAccent,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Below header: Thin cyan line separator
        Divider(
            color = cyanAccent.copy(alpha = 0.6f),
            thickness = 1.dp
        )

        // Sub-page or Main Folder Stack
        when (activeFolder) {
            null -> {
                // MAIN FOLDER STACK (Variation 01)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // 1. ACCOUNT & PROFILE
                    SettingsFolderItemRow(
                        title = "ACCOUNT & PROFILE",
                        icon = Icons.Default.Person,
                        isDark = isDark,
                        onClick = { activeFolder = SettingsFolder.ACCOUNT_PROFILE }
                    )

                    // 2. NOTIFICATIONS
                    SettingsFolderItemRow(
                        title = "NOTIFICATIONS",
                        icon = Icons.Default.Notifications,
                        isDark = isDark,
                        onClick = { activeFolder = SettingsFolder.NOTIFICATIONS }
                    )

                    // 3. PRIVACY & SECURITY
                    SettingsFolderItemRow(
                        title = "PRIVACY & SECURITY",
                        icon = Icons.Default.Security,
                        isDark = isDark,
                        onClick = { activeFolder = SettingsFolder.PRIVACY_SECURITY }
                    )

                    // 4. DISPLAY & APPEARANCE
                    SettingsFolderItemRow(
                        title = "DISPLAY & APPEARANCE",
                        icon = Icons.Default.Palette,
                        isDark = isDark,
                        onClick = { activeFolder = SettingsFolder.DISPLAY_APPEARANCE }
                    )

                    // 5. STORAGE & DATA
                    SettingsFolderItemRow(
                        title = "STORAGE & DATA",
                        icon = Icons.Default.Storage,
                        isDark = isDark,
                        onClick = { activeFolder = SettingsFolder.STORAGE_DATA }
                    )

                    Spacer(modifier = Modifier.weight(1f, fill = false))
                    Spacer(modifier = Modifier.height(32.dp))

                    // Footer: Small text center bottom "v2.4.1 • SECURE MODE ACTIVE" in cyan
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "v2.4.1 • SECURE MODE ACTIVE",
                            color = cyanAccent,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            SettingsFolder.ACCOUNT_PROFILE -> {
                // Sub-page 1: ACCOUNT & PROFILE
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // Operator Profile Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, cyanAccent.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBgColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(cyanAccent.copy(alpha = 0.15f))
                                    .border(1.2.dp, cyanAccent, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = cyanAccent,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "OPERATOR: MAJIDUL (BOSS)",
                                    color = textColorPrimary,
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "SECURITY CLEARANCE: LEVEL 10 (MASTER ADMIN)",
                                    color = cyanAccent,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "UPLINK: STARK SATELLITE 7 ACTIVE",
                                    color = textColorSecondary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // AMAR VOICE BIOMETRIC LOCK (MY VOICE)
                    Text(
                        text = "AMAR VOICE BIOMETRICS (MAJIDUL BOSS LOCK)",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    VoiceBiometricEnrollmentCard(viewModel = viewModel)

                    Spacer(modifier = Modifier.height(20.dp))

                    // OPERATIONAL PERSONAS & ROLES
                    Text(
                        text = "OPERATIONAL PERSONA // COMPLIANCE PROTOCOL",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        JarvisPersona.values().forEach { persona ->
                            val isSelected = viewModel.currentPersona == persona
                            Surface(
                                onClick = {
                                    viewModel.selectPersona(persona)
                                    Toast.makeText(context, "Activated: ${persona.title}", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) {
                                    if (persona == JarvisPersona.GIRLFRIEND_MODE) Color(0xFF8A2BE2).copy(alpha = 0.35f) else cyanAccent.copy(alpha = 0.25f)
                                } else cardBgColor,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) {
                                        if (persona == JarvisPersona.GIRLFRIEND_MODE) Color(0xFFFF69B4) else cyanAccent
                                    } else dividerColor
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (persona == JarvisPersona.GIRLFRIEND_MODE) Icons.Default.Favorite else Icons.Default.Security,
                                                contentDescription = null,
                                                tint = if (persona == JarvisPersona.GIRLFRIEND_MODE) Color(0xFFFF69B4) else cyanAccent,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = persona.title,
                                                color = textColorPrimary,
                                                fontSize = 12.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = persona.subtitle,
                                            color = textColorSecondary,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            viewModel.selectPersona(persona)
                                            Toast.makeText(context, "Activated: ${persona.title}", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = if (persona == JarvisPersona.GIRLFRIEND_MODE) Color(0xFFFF69B4) else cyanAccent
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // AI VOICE PERSONALITY
                    Text(
                        text = "AI VOICE PERSONALITY",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Male Voices List
                    Text("Male Voices Profile:", color = cyanAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                    ) {
                        viewModel.voices.filter { it.isMale }.forEach { voice ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectVoice(voice.name)
                                        viewModel.logAction("Voice Profile Selected: ${voice.name}")
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedVoiceName == voice.name,
                                    onClick = {
                                        viewModel.selectVoice(voice.name)
                                        viewModel.logAction("Voice Profile Selected: ${voice.name}")
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = cyanAccent)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = voice.name, color = textColorPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Female Voices List
                    Text("Female Voices Profile:", color = cyanAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                    ) {
                        viewModel.voices.filter { !it.isMale }.forEach { voice ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectVoice(voice.name)
                                        viewModel.logAction("Voice Profile Selected: ${voice.name}")
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedVoiceName == voice.name,
                                    onClick = {
                                        viewModel.selectVoice(voice.name)
                                        viewModel.logAction("Voice Profile Selected: ${voice.name}")
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = cyanAccent)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = voice.name, color = textColorPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            SettingsFolder.NOTIFICATIONS -> {
                // Sub-page 2: NOTIFICATIONS (AI INTELLIGENCE HUB, Feature 36, Feature 44)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // 1. AI MODELS & FREE KEYS
                    AiModelsAndFreeKeysCard(viewModel = viewModel)

                    Spacer(modifier = Modifier.height(16.dp))

                    // 2. FEATURE 36: AUTO REPLY AI
                    JarvisAutoReplyCard(viewModel = viewModel)

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3. FEATURE 44: SMART NOTIFICATION READER
                    JarvisNotificationReaderCard(viewModel = viewModel)
                }
            }

            SettingsFolder.PRIVACY_SECURITY -> {
                // Sub-page 3: PRIVACY & SECURITY (JARVIS SENTINEL & PRIVACY VAULT)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // Sentinel & Privacy Vault Full Card
                    JarvisSentinelVaultCard(viewModel = viewModel)

                    Spacer(modifier = Modifier.height(16.dp))

                    // Security Toggles
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, cyanAccent.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBgColor)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "CORE DEFENSE SHIELD CONTROLS",
                                color = StarkGold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Security Voice Lock", color = textColorPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text("Requires Majidul voice biometric to authenticate", color = textColorSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                Switch(
                                    checked = viewModel.securityVoiceLock,
                                    onCheckedChange = { viewModel.securityVoiceLock = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = cyanAccent, checkedTrackColor = cyanAccent.copy(alpha = 0.4f))
                                )
                            }

                            Divider(color = dividerColor, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Intruder Threat Alert", color = textColorPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text("Silent camera capture & lockout on rogue access", color = textColorSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                Switch(
                                    checked = viewModel.securityIntruderAlert,
                                    onCheckedChange = { viewModel.securityIntruderAlert = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = cyanAccent, checkedTrackColor = cyanAccent.copy(alpha = 0.4f))
                                )
                            }

                            Divider(color = dividerColor, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Network Firewall & Port Shield", color = textColorPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text("Blocks rogue outbound telemetry packets", color = textColorSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                Switch(
                                    checked = viewModel.securityFirewall,
                                    onCheckedChange = { viewModel.securityFirewall = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = cyanAccent, checkedTrackColor = cyanAccent.copy(alpha = 0.4f))
                                )
                            }
                        }
                    }
                }
            }

            SettingsFolder.DISPLAY_APPEARANCE -> {
                // Sub-page 4: DISPLAY & APPEARANCE (THEME MODE + HUD)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // [CARD 1] THEME MODE
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, cyanAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBgColor)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "THEME MODE",
                                color = cyanAccent,
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Select Appearance: Clean Light Mode or Cybernetic Stark Dark HUD",
                                color = textColorSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Button 1: LIGHT (Default)
                                Button(
                                    onClick = { viewModel.setTheme(false) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (!isDark) Color(0xFF0078FF) else (if (isDark) Color(0xFF102542) else Color(0xFFE8EEF8)),
                                        contentColor = if (!isDark) Color.White else (if (isDark) Color(0xFF7FA2BE) else Color(0xFF1A2332))
                                    ),
                                    border = BorderStroke(1.2.dp, if (!isDark) Color(0xFF0078FF) else cyanAccent.copy(alpha = 0.3f))
                                ) {
                                    Text(
                                        text = "☀️ LIGHT (Default)",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Button 2: DARK (JARVIS HUD)
                                Button(
                                    onClick = { viewModel.setTheme(true) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isDark) Color(0xFF00F5FF) else Color(0xFFE8EEF8),
                                        contentColor = if (isDark) Color.Black else Color(0xFF1A2332)
                                    ),
                                    border = BorderStroke(1.2.dp, if (isDark) Color(0xFF00F5FF) else Color(0xFF0078FF).copy(alpha = 0.3f))
                                ) {
                                    Text(
                                        text = "🌙 DARK (JARVIS HUD)",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Live Mode (Always ON)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                            .border(1.dp, dividerColor, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Live Mode (Always ON)",
                                color = textColorPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Maintains connection with Stark Satellite & real-time telemetry",
                                color = textColorSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Switch(
                            checked = isLiveMode,
                            onCheckedChange = {
                                viewModel.toggleLiveMode(it)
                                viewModel.logAction("Live Mode: ${if (it) "ENABLED" else "DISABLED"}")
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = cyanAccent,
                                checkedTrackColor = cyanAccent.copy(alpha = 0.4f),
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.DarkGray
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Torch & Beam controls
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, dividerColor, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBgColor)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Torch Max Beam", color = textColorPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("Hardware tactical illuminator status", color = textColorSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                            Switch(
                                checked = viewModel.isTorchOn,
                                onCheckedChange = { viewModel.toggleTorchOnly() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = StarkGold,
                                    checkedTrackColor = StarkGold.copy(alpha = 0.4f)
                                )
                            )
                        }
                    }
                }
            }

            SettingsFolder.STORAGE_DATA -> {
                // Sub-page 5: STORAGE & DATA (Room SQL Memory, Daemon, Duplex, Core, Apps, Automation)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // LONG TERM MEMORY ENGINE (ROOM SQL)
                    Text(
                        text = "LONG-TERM MEMORY ENGINE (ROOM SQL)",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    var memoryFactKey by remember { mutableStateOf("") }
                    var memoryFactValue by remember { mutableStateOf("") }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                            .border(1.dp, dividerColor, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Add Custom Fact to Long-Term Memory:",
                            color = cyanAccent,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = memoryFactKey,
                            onValueChange = { memoryFactKey = it },
                            placeholder = { Text("Topic (e.g. MyFavoriteCoffee)", color = textColorSecondary, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = textColorPrimary,
                                unfocusedTextColor = textColorPrimary,
                                focusedBorderColor = cyanAccent,
                                unfocusedBorderColor = cyanAccent.copy(alpha = 0.35f)
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = memoryFactValue,
                            onValueChange = { memoryFactValue = it },
                            placeholder = { Text("Details (e.g. Espresso with oat milk, no sugar)", color = textColorSecondary, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = textColorPrimary,
                                unfocusedTextColor = textColorPrimary,
                                focusedBorderColor = cyanAccent,
                                unfocusedBorderColor = cyanAccent.copy(alpha = 0.35f)
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (memoryFactKey.isNotBlank() && memoryFactValue.isNotBlank()) {
                                    viewModel.saveLongTermMemory(memoryFactKey.trim(), memoryFactValue.trim())
                                    Toast.makeText(context, "Saved to Room Memory!", Toast.LENGTH_SHORT).show()
                                    memoryFactKey = ""
                                    memoryFactValue = ""
                                } else {
                                    Toast.makeText(context, "Enter both key and details", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.align(Alignment.End),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = cyanAccent.copy(alpha = 0.25f),
                                contentColor = cyanAccent
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Store in Room Memory", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // AUTONOMOUS BACKGROUND DAEMON
                    Text(
                        text = "AUTONOMOUS BACKGROUND DAEMON",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                            .border(1.dp, dividerColor, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Foreground Autonomous Service",
                                color = textColorPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Listens for 'Hey Jarvis' offline wake-word & handles background triggers",
                                color = textColorSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Switch(
                            checked = viewModel.isForegroundAgentRunning,
                            onCheckedChange = { viewModel.toggleForegroundAgent() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = cyanAccent,
                                checkedTrackColor = cyanAccent.copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // REAL-TIME DUPLEX & BARGE-IN AUDIO
                    Text(
                        text = "REAL-TIME DUPLEX & BARGE-IN AUDIO",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                            .border(1.dp, dividerColor, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Duplex Voice Streaming",
                                color = textColorPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Acoustic barge-in instantly interrupts AI speech when you talk",
                                color = textColorSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Switch(
                            checked = viewModel.isDuplexEnabled,
                            onCheckedChange = { viewModel.toggleDuplexMode() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = cyanAccent,
                                checkedTrackColor = cyanAccent.copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // J.A.R.V.I.S. UNIFIED INTELLIGENCE ARCHITECTURE
                    Text(
                        text = "J.A.R.V.I.S. UNIFIED INTELLIGENCE CORE",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                            .border(1.dp, dividerColor, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = null,
                                tint = cyanAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "J.A.R.V.I.S. Core 4.0",
                                color = cyanAccent,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Singular autonomous intelligence integrating tactical system automation, full phone accessibility controls, Gemini multimodal vision, Room local memory, and dual voice synthesis engine.",
                            color = textColorSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // AUTHORIZED APPS FOR CONTROL
                    Text(
                        text = "AUTHORIZED APPS FOR CONTROL",
                        color = StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Select apps that JARVIS can control via gestures and voice simulations:",
                        color = textColorSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    val appOptions = listOf("WhatsApp", "YouTube", "Spotify", "Gallery", "Call Service", "SMS", "Facebook")
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(cardBgColor)
                            .border(1.dp, dividerColor, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        appOptions.forEach { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.toggleAppPermission(app)
                                        viewModel.logAction("App Access Toggled: $app")
                                    }
                                    .padding(vertical = 6.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = app,
                                    color = if (allowedApps.contains(app)) cyanAccent else textColorPrimary,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Checkbox(
                                    checked = allowedApps.contains(app),
                                    onCheckedChange = {
                                        viewModel.toggleAppPermission(app)
                                        viewModel.logAction("App Access Toggled: $app")
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = cyanAccent,
                                        uncheckedColor = textColorSecondary
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // DEDICATED STATUS FOLDER: AUTOMATION SERVICE & CONTROLLER
                    JarvisAutomationStatusFolder(viewModel = viewModel)
                }
            }
        }
    }
}
