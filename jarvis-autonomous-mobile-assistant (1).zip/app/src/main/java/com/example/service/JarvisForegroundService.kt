package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Autonomous Foreground Service Worker for J.A.R.V.I.S.
 * Keeps offline wake-word listener active, executes background agent workflows,
 * and maintains continuous system awareness without being killed by Android OS.
 */
class JarvisForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var wakeWordDetector: JarvisWakeWordDetector? = null

    companion object {
        const val CHANNEL_ID = "jarvis_autonomous_service_channel"
        const val NOTIFICATION_ID = 4001
        const val ACTION_START = "ACTION_START_AUTONOMOUS_AGENT"
        const val ACTION_STOP = "ACTION_STOP_AUTONOMOUS_AGENT"

        @Volatile
        private var isRunning = false
        fun isServiceActive(): Boolean = isRunning

        private val _wakeWordEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
        val wakeWordEvents: SharedFlow<String> = _wakeWordEvents.asSharedFlow()

        fun startService(context: Context) {
            val intent = Intent(context, JarvisForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, JarvisForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        wakeWordDetector = JarvisWakeWordDetector(this) { detectedWord ->
            _wakeWordEvents.tryEmit(detectedWord)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopWakeWordListener()
                isRunning = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                val notification = buildForegroundNotification("J.A.R.V.I.S. Core 4.0 Autonomous Engine Online")
                startForeground(NOTIFICATION_ID, notification)
                isRunning = true
                wakeWordDetector?.startListening(serviceScope)
                return START_STICKY
            }
        }
    }

    private fun stopWakeWordListener() {
        wakeWordDetector?.stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        stopWakeWordListener()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Autonomous Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps JARVIS autonomous phone automator & offline wake-word active"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S.")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
