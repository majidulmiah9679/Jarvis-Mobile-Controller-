package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.HashSet

class JarvisAutomationService : AccessibilityService() {

    val automator: com.example.automation.EnhancedAccessibilityAutomator by lazy {
        com.example.automation.EnhancedAccessibilityAutomator { this }
    }

    companion object {
        @Volatile
        private var instance: JarvisAutomationService? = null

        @JvmStatic
        fun getInstance(): JarvisAutomationService? {
            return instance
        }

        fun getAutomator(): com.example.automation.EnhancedAccessibilityAutomator? {
            return instance?.automator
        }

        fun isServiceRunning(): Boolean {
            return instance != null
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName == null) return
        val currentPackage = event.packageName.toString()

        val prefs: SharedPreferences = getSharedPreferences("JarvisSettings", Context.MODE_PRIVATE)
        val selectedApps: Set<String> = prefs.getStringSet("selected_apps", HashSet<String>()) ?: HashSet<String>()

        // ইউজার সেটিংসে সিলেক্ট করা অ্যাপ চেক করা
        if (selectedApps.contains(currentPackage)) {
            // উইন্ডোর কন্টেন্ট পরিবর্তন হলে নোড রিড করা বা অটো কাজ চালানো সম্ভব
            val rootNode: AccessibilityNodeInfo? = rootInActiveWindow
            if (rootNode != null) {
                // এক্সাম্পল: নির্দিষ্ট কোনো বাটনে ক্লিক বা কাজ
                rootNode.recycle()
            }
        }
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    // স্ক্রিনের যেকোনো কোঅর্ডিনেটে অটো ট্যাপ করার মেথড
    fun autoClick(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val clickPath = Path()
            clickPath.moveTo(x, y)
            val clickStroke = GestureDescription.StrokeDescription(clickPath, 0, 50)
            val gestureBuilder = GestureDescription.Builder()
            gestureBuilder.addStroke(clickStroke)
            return dispatchGesture(gestureBuilder.build(), null, null)
        }
        return false
    }

    // স্ক্রল ডাউন অটোমেশন মেথড
    fun autoScrollDown(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val scrollPath = Path()
            // স্ক্রিনের মাঝখান থেকে নিচ থেকে উপরে সোয়াইপ (স্ক্রল ডাউন)
            scrollPath.moveTo(500f, 1500f)
            scrollPath.lineTo(500f, 500f)
            val scrollStroke = GestureDescription.StrokeDescription(scrollPath, 0, 300)
            val gestureBuilder = GestureDescription.Builder()
            gestureBuilder.addStroke(scrollStroke)
            return dispatchGesture(gestureBuilder.build(), null, null)
        }
        return false
    }

    // নোড টেক্সট বা আইডি দিয়ে ক্লিক
    fun clickByText(text: String): Int {
        var clickedCount = 0
        val rootNode: AccessibilityNodeInfo? = rootInActiveWindow
        if (rootNode != null) {
            val nodes = rootNode.findAccessibilityNodeInfosByText(text)
            if (nodes != null) {
                for (node in nodes) {
                    if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        clickedCount++
                    }
                }
            }
            rootNode.recycle()
        }
        return clickedCount
    }

    // Extended UI Automation Helpers
    fun swipeHorizontal(fromLeftToRight: Boolean): Boolean {
        return if (fromLeftToRight) {
            automator.performSwipe(150f, 1000f, 900f, 1000f, 300L)
        } else {
            automator.performSwipe(900f, 1000f, 150f, 1000f, 300L)
        }
    }

    fun inputTextToField(targetQuery: String, text: String): Boolean {
        return automator.findAndSetText(targetQuery, text)
    }

    fun pressBack(): Boolean = automator.performGlobalBack()
    fun pressHome(): Boolean = automator.performGlobalHome()
    fun pressRecents(): Boolean = automator.performGlobalRecents()
}
